(() => {
var exports = {};
exports.id = 273;
exports.ids = [273];
exports.modules = {

/***/ 6301:
/***/ ((module) => {

// Exports
module.exports = {
	"pageCover": "in_pageCover__VRSGb",
	"coverTitle": "in_coverTitle__tllTs",
	"pageData": "in_pageData__Yaxb4",
	"pageDataIn": "in_pageDataIn__B2AfB",
	"pageNavigator": "in_pageNavigator__BPdnZ",
	"navlink": "in_navlink__cBTfb",
	"navlink__active": "in_navlink__active__nqQId",
	"pageRealData": "in_pageRealData__eqsPm",
	"contentParagraph": "in_contentParagraph__V1WiG",
	"contentParagraph_copy1": "in_contentParagraph_copy1__jJTlU",
	"contentParagraph_copy1_text": "in_contentParagraph_copy1_text__4NN5T",
	"contentParagraph_copy1_img": "in_contentParagraph_copy1_img___wfmW",
	"contentParagraph_copy2": "in_contentParagraph_copy2__HxUX9",
	"contentMainTitle": "in_contentMainTitle__5k3BH",
	"contentMainTitle_copy": "in_contentMainTitle_copy__09xzi",
	"titleIconContainer": "in_titleIconContainer__Q1dvw",
	"titleIcon": "in_titleIcon__agfp6",
	"contentText": "in_contentText__C5FtS",
	"coursesListTitle": "in_coursesListTitle__NoYSb",
	"coursesListContainer": "in_coursesListContainer__0SUig",
	"coursesListFormContainer": "in_coursesListFormContainer__sQ7Gu",
	"coursesListFormFullRow": "in_coursesListFormFullRow__cc8oT",
	"coursesListFormHalfRow": "in_coursesListFormHalfRow__ZY4ro",
	"coursesFormInput": "in_coursesFormInput__TRVBi",
	"filled": "in_filled__Dqy94",
	"datePickerClearIcon": "in_datePickerClearIcon__WKRTr",
	"coursesFormButton": "in_coursesFormButton__F9rA7",
	"coursesList": "in_coursesList__Bj2ao",
	"courseItem": "in_courseItem__W9Zbl",
	"courseItemIn": "in_courseItemIn__WoLXA",
	"courseItemIn2": "in_courseItemIn2__hjR7Y",
	"courseItemCircle": "in_courseItemCircle__nkpb_",
	"courseItemInInside": "in_courseItemInInside__DmE8f",
	"courseItemInInside2": "in_courseItemInInside2__hbTT2",
	"courseItemInInsideImg": "in_courseItemInInsideImg__LVbqk",
	"courseItemInInsideText": "in_courseItemInInsideText__pQxIH",
	"courseItemInInside2Img": "in_courseItemInInside2Img__4bFTZ",
	"courseItemInInside2Text": "in_courseItemInInside2Text__ztehO",
	"courseItemInInsideImg_link": "in_courseItemInInsideImg_link__P2dQ7",
	"courseItemInInsideText_link": "in_courseItemInInsideText_link__6vSZd",
	"loader": "in_loader__Q2oDD"
};


/***/ }),

/***/ 4310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3195);
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6466);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5368);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(197);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5__);






_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__.library.add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__.fas, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5__.far, _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__.fab);
const IconComponent = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
        icon: `${[
            props.name
        ]}`,
        className: props.className ? props.className : "socialIcons"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IconComponent);


/***/ }),

/***/ 5505:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./pages/serves/in.module.css
var in_module = __webpack_require__(6301);
var in_module_default = /*#__PURE__*/__webpack_require__.n(in_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/NavLink/index.js
var NavLink = __webpack_require__(1967);
// EXTERNAL MODULE: ./components/iconComponent/index.js
var iconComponent = __webpack_require__(4310);
;// CONCATENATED MODULE: external "react-datepicker"
const external_react_datepicker_namespaceObject = require("react-datepicker");
var external_react_datepicker_default = /*#__PURE__*/__webpack_require__.n(external_react_datepicker_namespaceObject);
// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(5994);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./store/slices/generalSlice.js
var generalSlice = __webpack_require__(4486);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "validator"
var external_validator_ = __webpack_require__(1564);
var external_validator_default = /*#__PURE__*/__webpack_require__.n(external_validator_);
// EXTERNAL MODULE: external "react-spinners/BeatLoader"
var BeatLoader_ = __webpack_require__(3060);
var BeatLoader_default = /*#__PURE__*/__webpack_require__.n(BeatLoader_);
// EXTERNAL MODULE: ./utils/helperFunctions.js
var helperFunctions = __webpack_require__(8365);
;// CONCATENATED MODULE: ./pages/serves/[id].js

















//create floating text input
function TextInput({ type ="text" , label , name , required =false , value , setter ,  }) {
    // const [value, setValue] = useState("");
    function handleChange(e) {
        setter(e.target.value);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (in_module_default()).coursesFormInput,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("input", {
                type: type,
                value: value,
                onChange: handleChange,
                name: name,
                required: required
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                className: value && (in_module_default()).filled,
                htmlFor: name,
                children: label
            })
        ]
    });
}
//create floating select
function SelectInput({ type ="text" , label , name , onclick , coursescats =undefined , setter , value , lang ,  }) {
    // const [value, setValue] = useState("");
    function handleChange(e) {
        setter(e.target.value);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (in_module_default()).coursesFormInput,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                onClick: onclick,
                onChange: handleChange,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("option", {
                        defaultValue: "",
                        value: ""
                    }),
                    coursescats?.map((item)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsx)("option", {
                            value: item.id,
                            defaultValue: value,
                            children: (0,helperFunctions/* whatLanguage */.V)(lang, item, "title")
                        }, item.id);
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                className: value && (in_module_default()).filled,
                htmlFor: name,
                children: label
            })
        ]
    });
}
//date picker custom input
// eslint-disable-next-line react/display-name
const FloatingDatePicker = /*#__PURE__*/ (0,external_react_.forwardRef)(({ value , onClick , name , label , type ="text"  }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (in_module_default()).coursesFormInput,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("input", {
                type: type,
                value: value,
                onClick: onClick
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                className: value && (in_module_default()).filled,
                htmlFor: name,
                children: label
            })
        ]
    }));
const LearningIn = ({ serve , courses , coursescats , lang  })=>{
    const router = (0,router_.useRouter)();
    const { id  } = router.query;
    //datepicker state:
    const siteData = (0,external_react_redux_.useSelector)(generalSlice/* showSiteData */.KE);
    const { 0: thecourses , 1: setTheCourses  } = (0,external_react_.useState)(courses);
    const { 0: loadingCourses , 1: setLoadingCourses  } = (0,external_react_.useState)(false);
    const { t  } = (0,external_next_i18next_.useTranslation)([
        "common"
    ]);
    const theserve = serve.serves || "";
    const form = (0,external_react_.useRef)();
    const { 0: filter_title , 1: setFilterTitle  } = (0,external_react_.useState)("");
    const { 0: filter_cat , 1: setFilterCat  } = (0,external_react_.useState)(0);
    const { 0: startDate , 1: setStartDate  } = (0,external_react_.useState)("");
    const filterCourses = async (e)=>{
        setLoadingCourses(true);
        e.preventDefault();
        // const inputData = e.target.elements;
        let coursedate = "";
        let searchParam = "";
        //validate date
        if (startDate !== "") {
            if (external_validator_default().isDate(startDate)) {
                let month = String(startDate.getUTCMonth() + 1); //months from 1-12
                if (month.length === 1) {
                    month = "0" + month;
                }
                const day = startDate.getUTCDate();
                const year = startDate.getUTCFullYear();
                // const newdate = year + "/" + month + "/" + day;
                coursedate = year + "-" + month;
                searchParam += `&date=${coursedate}`;
                console.log("dateeee", coursedate);
            } else {
                console.log("not dateeee");
                return;
            }
        }
        if (filter_title !== "") {
            if (external_validator_default().isAlphanumeric(filter_title, [
                "he"
            ], {
                ignore: " "
            }) || external_validator_default().isAlphanumeric(filter_title, [
                "en-US"
            ], {
                ignore: " "
            })) {
                console.log("titleeee");
                searchParam += `&title=${filter_title}`;
            } else {
                console.log("wrong title");
                return;
            }
        }
        if (filter_cat !== "") {
            searchParam += `&cat=${filter_cat}`;
        }
        let searchStr = searchParam !== "" ? searchParam.substring(1) : "";
        searchStr = searchStr !== "" ? "?" + searchStr : searchStr;
        console.log(searchStr);
        const res = await fetch(`${"https://qrs-global.com"}/react/courses/index.php${searchStr}`);
        const courses = await res.json();
        setTheCourses([]);
        courses && setTheCourses(courses.allcourses);
        setLoadingCourses(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            siteData["Title"],
                            " | ",
                            (0,helperFunctions/* whatLanguage */.V)(lang, theserve, "title")
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                id: "pageCover",
                className: (in_module_default()).pageCover,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                    alt: "page cover",
                    src: "/img/learningcover.jpg",
                    layout: "fill",
                    objectFit: "cover"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                id: "pageData",
                className: (in_module_default()).pageData,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    id: "pageDataIn",
                    className: (in_module_default()).pageDataIn,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (in_module_default()).pageRealData,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (in_module_default()).pageNavigator,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                        href: "/",
                                        className: (in_module_default()).navlink,
                                        activeClassName: (in_module_default()).navlink__active,
                                        title: t("common:home")
                                    }),
                                    "/",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                        href: "/serves",
                                        className: (in_module_default()).navlink,
                                        activeClassName: (in_module_default()).navlink__active,
                                        title: t("common:serves")
                                    }),
                                    "/",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                        href: `/serves/${id}`,
                                        className: (in_module_default()).navlink,
                                        activeClassName: (in_module_default()).navlink__active,
                                        title: `${(0,helperFunctions/* whatLanguage */.V)(lang, theserve, "title")}`
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (in_module_default()).contentParagraph_copy1,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (in_module_default()).contentParagraph_copy1_text,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (in_module_default()).contentMainTitle_copy,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                        className: (in_module_default()).titleIconContainer,
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(iconComponent/* default */.Z, {
                                                            name: "fa-sharp fa-solid fa-chalkboard-user",
                                                            className: (in_module_default()).titleIcon
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                        children: (0,helperFunctions/* whatLanguage */.V)(lang, theserve, "title")
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (in_module_default()).contentText,
                                                dangerouslySetInnerHTML: {
                                                    __html: (0,helperFunctions/* whatLanguage */.V)(lang, theserve, "text")
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                        className: (in_module_default()).contentParagraph_copy1_img,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                            alt: "page cover",
                                            src: "/img/servesin.png",
                                            width: 624,
                                            height: 670,
                                            objectFit: "scale-down"
                                        })
                                    })
                                ]
                            }),
                            (theserve.title?.includes("courses") || theserve.title?.includes("הדרכות") || theserve.title?.includes("קורסים")) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (in_module_default()).contentParagraph_copy2,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                        className: (in_module_default()).coursesListTitle,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("h2", {
                                            children: t("common:courseslist")
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (in_module_default()).coursesListContainer,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (in_module_default()).coursesListFormContainer,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                    ref: form,
                                                    onSubmit: filterCourses,
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                            className: (in_module_default()).coursesListFormFullRow,
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(TextInput, {
                                                                label: t("common:title"),
                                                                name: "address",
                                                                type: "input",
                                                                setter: setFilterTitle,
                                                                value: filter_title
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (in_module_default()).coursesListFormFullRow,
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: (in_module_default()).coursesListFormHalfRow,
                                                                    style: {
                                                                        paddingInlineEnd: "10px"
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)((external_react_datepicker_default()), {
                                                                            type: "input",
                                                                            selected: startDate,
                                                                            onChange: (date)=>setStartDate(date),
                                                                            customInput: /*#__PURE__*/ (0,jsx_runtime_.jsx)(FloatingDatePicker, {
                                                                                name: "startdate",
                                                                                label: t("common:fromdate")
                                                                            }),
                                                                            dateFormat: "MM/dd/yyyy"
                                                                        }),
                                                                        startDate ? /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                            onClick: ()=>setStartDate(""),
                                                                            className: (in_module_default()).datePickerClearIcon,
                                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(iconComponent/* default */.Z, {
                                                                                type: "fab",
                                                                                name: "fa-solid fa-x"
                                                                            })
                                                                        }) : ""
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: (in_module_default()).coursesListFormHalfRow,
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                        className: (in_module_default()).coursesFormInput,
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(SelectInput, {
                                                                            name: "cat",
                                                                            value: filter_cat,
                                                                            setter: setFilterCat,
                                                                            coursescats: coursescats,
                                                                            label: t("common:choosecategory"),
                                                                            lang: lang
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: (in_module_default()).coursesListFormHalfRow,
                                                                    style: {
                                                                        flex: 0.7,
                                                                        marginInlineStart: "0.5vw"
                                                                    },
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("button", {
                                                                        className: (in_module_default()).coursesFormButton,
                                                                        children: t("common:search")
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (in_module_default()).coursesList,
                                                children: !loadingCourses && thecourses ? thecourses?.map((item, index)=>{
                                                    return index % 2 === 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                        className: (in_module_default()).courseItem,
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                            className: (in_module_default()).courseItemIn,
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: (in_module_default()).courseItemInInside,
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                        className: (in_module_default()).courseItemInInsideImg,
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(NavLink/* default */.Z, {
                                                                            href: `/serves/course/${item.id}`,
                                                                            className: (in_module_default()).courseItemInInsideImg_link,
                                                                            activeClassName: (in_module_default()).courseItemInInsideImg_link,
                                                                            children: [
                                                                                t("common:todetails"),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("br", {}),
                                                                                t("common:andregister")
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                        className: (in_module_default()).courseItemInInsideText,
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(NavLink/* default */.Z, {
                                                                            href: `/serves/course/${item.id}`,
                                                                            className: (in_module_default()).courseItemInInsideText_link,
                                                                            activeClassName: (in_module_default()).courseItemInInsideText_link,
                                                                            children: [
                                                                                (0,helperFunctions/* whatLanguage */.V)(lang, item, "title"),
                                                                                " ",
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("br", {}),
                                                                                (0,helperFunctions/* whatLanguage */.V)(lang, item, "description")
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }, item.id) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: (in_module_default()).courseItem,
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                className: (in_module_default()).courseItemIn2,
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: (in_module_default()).courseItemInInside2,
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                            className: (in_module_default()).courseItemInInside2Text,
                                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(NavLink/* default */.Z, {
                                                                                href: `/serves/course/${item.id}`,
                                                                                className: (in_module_default()).courseItemInInsideText_link,
                                                                                activeClassName: (in_module_default()).courseItemInInsideText_link,
                                                                                children: [
                                                                                    (0,helperFunctions/* whatLanguage */.V)(lang, item, "title"),
                                                                                    " ",
                                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("br", {}),
                                                                                    (0,helperFunctions/* whatLanguage */.V)(lang, item, "description")
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                            className: (in_module_default()).courseItemInInside2Img,
                                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(NavLink/* default */.Z, {
                                                                                href: `/serves/course/${item.id}`,
                                                                                className: (in_module_default()).courseItemInInsideImg_link,
                                                                                activeClassName: (in_module_default()).courseItemInInsideImg_link,
                                                                                children: [
                                                                                    t("common:todetails"),
                                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("br", {}),
                                                                                    t("common:andregister")
                                                                                ]
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                className: (in_module_default()).courseItemCircle
                                                            })
                                                        ]
                                                    }, item.id);
                                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                    className: (in_module_default()).loader,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((BeatLoader_default()), {
                                                        color: "#004b8d",
                                                        size: 15,
                                                        "aria-label": "Loading Spinner",
                                                        "data-testid": "loader"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
// This function gets called at build time
async function getServerSideProps({ params , locale  }) {
    // Call an external API endpoint to get posts
    const res = await fetch(`${"https://qrs-global.com"}/react/serves/serves.php`);
    const serves = await res.json();
    // Get the paths we want to pre-render based on posts
    const paths = serves.allserves.map((serve)=>({
            params: {
                id: serve.id
            }
        }));
    const res2 = await fetch(`${"https://qrs-global.com"}/react/serves/index.php?id=${params.id}`);
    const serve = await res2.json();
    let courses = null;
    let coursescats = null;
    if (serve?.serves?.title?.includes("courses") || serve?.serves?.title?.includes("הדרכות") || serve?.serves?.title?.includes("קורסים")) {
        const res3 = await fetch(`${"https://qrs-global.com"}/react/courses/index.php`);
        courses = await res3.json();
        const res4 = await fetch(`${"https://qrs-global.com"}/react/courses/cats.php`);
        coursescats = await res4.json();
    }
    if (false) {}
    return {
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale ?? "he"),
            lang: locale ?? "he",
            serve,
            courses: courses?.allcourses || null,
            coursescats: coursescats?.allcoursescats || null,
            paths: [
                ...paths
            ],
            fallback: false
        }
    };
}
// This also gets called at build time
// export async function getStaticProps({ params }) {
//   // params contains the post `id`.
//   // If the route is like /posts/1, then params.id is 1
//   const res = await fetch(
//     `https://qrs-global.com/react/serves/index.php?id=${params.id}`
//   );
//   const serve = await res.json();
//   // Pass post data to the page via props
//   return {
//     props: {
//       serve,
//     },
//   };
// }
// Learning.title = 'Learning';
/* harmony default export */ const _id_ = (LearningIn);


/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 5994:
/***/ (() => {



/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-regular-svg-icons");

/***/ }),

/***/ 6466:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1564:
/***/ ((module) => {

"use strict";
module.exports = require("validator");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967], () => (__webpack_exec__(5505)));
module.exports = __webpack_exports__;

})();