(() => {
var exports = {};
exports.id = 97;
exports.ids = [97,983];
exports.modules = {

/***/ 6093:
/***/ ((module) => {

// Exports
module.exports = {
	"pageCover": "indexid_pageCover__sm1Ek",
	"pageData": "indexid_pageData__yqZ_C",
	"pageDataInContainer": "indexid_pageDataInContainer___2Zwr",
	"courseInfoContainer": "indexid_courseInfoContainer__b47U_",
	"courseInfoTitle": "indexid_courseInfoTitle__wrWTO",
	"contentMainTitle_copy": "indexid_contentMainTitle_copy__yuENv",
	"titleIconContainer": "indexid_titleIconContainer__CkQ7G",
	"titleIcon": "indexid_titleIcon__K1fkO",
	"courseInfoNav": "indexid_courseInfoNav__ztao5",
	"navDataDiv": "indexid_navDataDiv__sghEk",
	"pageDataIn": "indexid_pageDataIn__hkCCY",
	"productsContainer": "indexid_productsContainer__8q3bg",
	"filterContainer": "indexid_filterContainer__5S21u",
	"filterContainerIn": "indexid_filterContainerIn__O0nDG",
	"filterCircle": "indexid_filterCircle__55hhL",
	"filterCircleIn": "indexid_filterCircleIn___nUKu",
	"productsHeader": "indexid_productsHeader__HkYRA",
	"productsHeaderDead": "indexid_productsHeaderDead__QLnme",
	"productsHeaderActive": "indexid_productsHeaderActive__TRBm0",
	"productsHeaderActiveTitle": "indexid_productsHeaderActiveTitle__49JCP",
	"productsHeaderActiveNav": "indexid_productsHeaderActiveNav__r61Er",
	"pageNavigator": "indexid_pageNavigator__1i_ni",
	"navlink": "indexid_navlink__LWKXM",
	"navlink__active": "indexid_navlink__active__8JCLk",
	"productsList": "indexid_productsList__o7Fhl",
	"productsListIn": "indexid_productsListIn___KaAv",
	"productsListUl": "indexid_productsListUl__H3TG1",
	"productItemContainer": "indexid_productItemContainer__Rw9tN",
	"productItemTextFull": "indexid_productItemTextFull__PYSZa",
	"productItemTextFullIn": "indexid_productItemTextFullIn__ASOKu",
	"productItemText": "indexid_productItemText__aoNeY",
	"productItemImg": "indexid_productItemImg__OMUDB",
	"productItemText2": "indexid_productItemText2__PQ1iz",
	"productItemText2_desc": "indexid_productItemText2_desc__1p8IS",
	"filterImg": "indexid_filterImg__M4Khc",
	"filterItemsContainer": "indexid_filterItemsContainer__UHthr",
	"filterItemCat": "indexid_filterItemCat__2o1S4",
	"filterItemTitle": "indexid_filterItemTitle__gjve8",
	"filterItemInput": "indexid_filterItemInput__sWXrX",
	"filterItemInputLabel": "indexid_filterItemInputLabel__6Tk7q",
	"realLeftSide": "indexid_realLeftSide__F1n3_",
	"realLeftSide_greyTitle": "indexid_realLeftSide_greyTitle__VUlSd",
	"realLeftSide_lines": "indexid_realLeftSide_lines__q1xsm",
	"realLeftSide_lines_a": "indexid_realLeftSide_lines_a__8hM7G",
	"realLeftSide_lines_a_error": "indexid_realLeftSide_lines_a_error__OcizL",
	"realLeftSide_lines_a_item": "indexid_realLeftSide_lines_a_item__jRMld",
	"realLeftSide_lines_b": "indexid_realLeftSide_lines_b__OBVvZ",
	"realLeftSide_lines_b_iconContainer": "indexid_realLeftSide_lines_b_iconContainer__G_UER",
	"realLeftSide_lines_b_iconCover": "indexid_realLeftSide_lines_b_iconCover__jhNtI",
	"realLeftSide_lines_b_icon": "indexid_realLeftSide_lines_b_icon__hT16A",
	"realLeftSide_blueTitle": "indexid_realLeftSide_blueTitle__MF5jy",
	"realLeftSide_form_input": "indexid_realLeftSide_form_input__daxIL",
	"realLeftSide_form_input_opp": "indexid_realLeftSide_form_input_opp__TbEpt",
	"realLeftSide_form_input_opp_in": "indexid_realLeftSide_form_input_opp_in__8D9fV",
	"realLeftSide_form_button": "indexid_realLeftSide_form_button__qB6Tk",
	"productContentLine": "indexid_productContentLine__d5Uj2",
	"productContentLine_a": "indexid_productContentLine_a__X3YUP",
	"productContentLine_b": "indexid_productContentLine_b__YuAsK",
	"courseInfoTitle1": "indexid_courseInfoTitle1__I3Zcv",
	"courseInfoTitle2": "indexid_courseInfoTitle2__y_JCk"
};


/***/ }),

/***/ 4310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3195);
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6466);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5368);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(197);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5__);






_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__.library.add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__.fas, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_5__.far, _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_4__.fab);
const IconComponent = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
        icon: `${[
            props.name
        ]}`,
        className: props.className ? props.className : "socialIcons"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IconComponent);


/***/ }),

/***/ 8643:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _indexid_module_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6093);
/* harmony import */ var _indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_indexid_module_css__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_NavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4486);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_animated_checkbox__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3061);
/* harmony import */ var react_animated_checkbox__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_animated_checkbox__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_iconComponent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4310);
/* harmony import */ var _utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8365);
/* harmony import */ var _store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5848);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_12__]);
react_toastify__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable react/no-unescaped-entities */ 
















const LeftSide = ({ product , lang  })=>{
    //the currect way to use translation!!!
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)([
        "common"
    ]);
    const { 0: qty , 1: setQty  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
    const changeQuantity = (action)=>{
        if (action !== "plus" && action !== "minus") return;
        action === "plus" ? setQty(qty + 1) : qty >= 2 ? setQty(qty - 1) : false;
    };
    const { 0: radios , 1: setRadios  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const { 0: radioserrors , 1: setRadiosErrors  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    function handleRadios(e, param) {
        if (radios[param] && radios[param] !== "" && radios[param] === e.target.value) {
            const { [param]: tmp , ...rest } = radios;
            setRadios(rest);
        } else {
            setRadios({
                ...radios,
                [param]: e.target.value
            });
        }
    }
    const notify = (msg, type)=>{
        react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.dismiss();
        if (type === "success") {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.success(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        } else {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.error(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        }
    };
    const addToCartFunc = ()=>{
        let newerrarray = [
            ...radioserrors
        ];
        if (product.diameter?.length > 0) {
            if (radios["diameter"]) {
                console.log("exists diameter");
                const index = newerrarray.indexOf("diameter");
                if (index > -1) {
                    // only splice array when item is found
                    newerrarray.splice(index, 1); // 2nd parameter means remove one item only
                }
                setRadiosErrors(newerrarray);
            } else {
                if (!newerrarray.includes("diameter")) {
                    newerrarray.push("diameter");
                    setRadiosErrors(newerrarray);
                }
            }
        }
        if (product.height?.length > 0) {
            if (radios["height"]) {
                console.log("exists height");
                const index1 = newerrarray.indexOf("height");
                if (index1 > -1) {
                    // only splice array when item is found
                    newerrarray.splice(index1, 1); // 2nd parameter means remove one item only
                }
                setRadiosErrors(newerrarray);
            } else {
                if (!newerrarray.includes("height")) {
                    newerrarray.push("height");
                    setRadiosErrors(newerrarray);
                }
            }
        }
        if (product.tissuelevel?.length > 0) {
            if (radios["tissuelevel"]) {
                console.log("exists tissuelevel");
                const index2 = newerrarray.indexOf("tissuelevel");
                if (index2 > -1) {
                    // only splice array when item is found
                    newerrarray.splice(index2, 1); // 2nd parameter means remove one item only
                }
                setRadiosErrors(newerrarray);
            } else {
                if (!newerrarray.includes("tissuelevel")) {
                    newerrarray.push("tissuelevel");
                    setRadiosErrors(newerrarray);
                }
            }
        }
        product.product_features?.map((item)=>{
            const feaname = item.featurecatname.toLowerCase().replace(/\s/g, "_");
            if (radios[feaname]) {
                const index = newerrarray.indexOf(feaname);
                if (index > -1) {
                    // only splice array when item is found
                    newerrarray.splice(index, 1); // 2nd parameter means remove one item only
                }
                setRadiosErrors(newerrarray);
            } else {
                if (!newerrarray.includes(feaname)) {
                    newerrarray.push(feaname);
                    setRadiosErrors(newerrarray);
                }
            }
        });
        if (newerrarray.length > 0) {
            notify(`${t("common:fixaddtocart")}`, "error");
        } else {
            dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_11__/* .addToCart */ .Xq)({
                ...product,
                qty: qty
            }));
            setQty(1);
            notify(`${t("common:productaddedtocart")}`, "success");
            setRadios({});
        }
    // alert(qty);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_greyTitle),
                style: {
                    borderRadius: "20px 20px 0 0"
                },
                children: t("products:productdetails")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a),
                        style: {
                            flex: 3
                        },
                        children: [
                            t("common:category"),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                        style: {
                            flex: 2
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            href: `/products/${product.cat_data.id}`,
                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink__active),
                            activeClassName: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink__active),
                            title: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product.cat_data, "title")
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productItemImg),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    alt: "page cover",
                    src: `https://qrs-global.com/uploads/${product.pic}`,
                    width: 221,
                    height: 221,
                    objectFit: "scale-down"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_greyTitle),
                children: t("products:toorder")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    direction: "ltr"
                },
                children: [
                    product.tissuelevel !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `${(_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a)} ${radioserrors.includes("tissuelevel") && (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_error)}`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                        style: {
                                            color: "red"
                                        },
                                        children: "*"
                                    }),
                                    "Tissue Level"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                children: Array.isArray(product.tissuelevel) && product.tissuelevel.map((item)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_item),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                        type: "radio",
                                                        name: item,
                                                        value: item,
                                                        onClick: (event)=>handleRadios(event, "tissuelevel"),
                                                        checked: radios.tissuelevel === item
                                                    }),
                                                    item
                                                ]
                                            })
                                        })
                                    }, item);
                                })
                            })
                        ]
                    }),
                    product.height !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `${(_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a)} ${radioserrors.includes("height") && (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_error)}`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                        style: {
                                            color: "red"
                                        },
                                        children: "*"
                                    }),
                                    "HEIGHT"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                children: Array.isArray(product.height) && product.height.map((item)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_item),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                        type: "radio",
                                                        name: item,
                                                        value: item,
                                                        onClick: (event)=>handleRadios(event, "height"),
                                                        checked: radios.height === item
                                                    }),
                                                    item
                                                ]
                                            })
                                        })
                                    }, item);
                                })
                            })
                        ]
                    }),
                    product.diameter !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `${(_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a)} ${radioserrors.includes("diameter") && (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_error)}`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                        style: {
                                            color: "red"
                                        },
                                        children: "*"
                                    }),
                                    "DIAMETER"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                children: Array.isArray(product.diameter) && product.diameter.map((item)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_item),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                        type: "radio",
                                                        name: item,
                                                        value: item,
                                                        onClick: (event)=>handleRadios(event, "diameter"),
                                                        checked: radios.diameter === item
                                                    }),
                                                    item
                                                ]
                                            })
                                        })
                                    }, item);
                                })
                            })
                        ]
                    }),
                    product.product_features !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines),
                        children: Array.isArray(product.product_features) && product.product_features.map((item)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `${(_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a)} ${radioserrors.includes(item.featurecatname.toLowerCase().replace(/\s/g, "_")) && (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_error)}`,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                style: {
                                                    color: "red"
                                                },
                                                children: "*"
                                            }),
                                            item.featurecatname
                                        ]
                                    }),
                                    Array.isArray(item.features) && item.features.map((itemfeatures)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_a_item),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_lines_b),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                            type: "radio",
                                                            name: itemfeatures.featurename,
                                                            value: itemfeatures.featureid,
                                                            onClick: (event)=>handleRadios(event, item.featurecatname.toLowerCase().replace(/\s/g, "_")),
                                                            checked: radios[item.featurecatname.toLowerCase().replace(/\s/g, "_")] === itemfeatures.featureid
                                                        }),
                                                        itemfeatures.featurename
                                                    ]
                                                })
                                            })
                                        }, itemfeatures.featureid);
                                    })
                                ]
                            }, item.featurecat);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_form_input),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_form_input_opp),
                                onClick: ()=>{
                                    changeQuantity("plus");
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_form_input_opp_in),
                                    unselectable: "on",
                                    onselectstart: "return false;",
                                    onmousedown: "return false;",
                                    children: "+"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                    type: "number",
                                    value: qty
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_form_input_opp),
                                onClick: ()=>{
                                    changeQuantity("minus");
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_form_input_opp_in),
                                    unselectable: "on",
                                    onselectstart: "return false;",
                                    onmousedown: "return false;",
                                    children: "-"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                        type: "hidden",
                        name: "productData"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().realLeftSide_form_button),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                            type: "button",
                            onClick: ()=>addToCartFunc(),
                            children: t("products:addtocart")
                        })
                    })
                ]
            })
        ]
    });
};
const ProductsInId = ({ product , lang  })=>{
    const siteData = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)(_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__/* .showSiteData */ .KE);
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)([
        "common"
    ]);
    //dispacher example to update states
    // const dispatcher = useDispatch();
    // useEffect(() => {
    //   name.name === 'mikha'
    //     ? dispatcher(nameAction.nameSamar())
    //     : dispatcher(nameAction.nameMikha());
    // }, []);
    //useSelector example to read states
    // let icon = useSelector((state) => state.icon);
    // let name = useSelector((state) => state.name);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_8___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            siteData["Title"],
                            " | ",
                            (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product, "title")
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageCover",
                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().pageCover),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    alt: "page cover",
                    src: "/img/productscover.png",
                    layout: "fill",
                    objectFit: "cover"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageData",
                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().pageData),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    id: "pageDataIn",
                    className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().pageDataInContainer),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "pageDataIn",
                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().pageDataIn),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productsContainer),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productsHeader),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productsHeaderActive),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().pageNavigator),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        href: "/",
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink),
                                                        activeClassName: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink__active),
                                                        title: t("common:home")
                                                    }),
                                                    "/",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        href: "/products",
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink),
                                                        activeClassName: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink__active),
                                                        title: t("common:products")
                                                    }),
                                                    "/",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        href: `/products/${product.cat_data.id}`,
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink),
                                                        activeClassName: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().navlink__active),
                                                        title: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product.cat_data, "title")
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productsList),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productsListIn),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productsListUl),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine),
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                                                            children: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product, "title")
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine),
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine_a),
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", {
                                                                    children: t("products:description")
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine_b),
                                                                dangerouslySetInnerHTML: {
                                                                    __html: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product, "text")
                                                                }
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine),
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine_a),
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", {
                                                                    children: t("products:features")
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine_b),
                                                                dangerouslySetInnerHTML: {
                                                                    __html: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product, "features")
                                                                }
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine),
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine_a),
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", {
                                                                    children: t("products:techinfo")
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().productContentLine_b),
                                                                dangerouslySetInnerHTML: {
                                                                    __html: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(lang, product, "techinfo")
                                                                }
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().filterContainer),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().filterContainerIn),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().filterItemsContainer),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(LeftSide, {
                                                product: product,
                                                lang: lang
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().filterCircle),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_indexid_module_css__WEBPACK_IMPORTED_MODULE_14___default().filterCircleIn)
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
// ProductsIn.title = `Products`;
async function getServerSideProps({ locale , params  }) {
    const res1 = await fetch(`https://qrs-global.com/react/products/product.php?id=${params.id}`);
    const data1 = await res1.json();
    if (false) {}
    return {
        props: {
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__.serverSideTranslations)(locale ?? "he"),
            product: data1?.product,
            lang: locale ?? "he"
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsInId); // import connectMongo from '../../utils/dbConnect';
 // import Samar from '../../models/toursModel';
 // const About = ({ samars }) => {
 //   return (
 //     <div>
 //       {samars.map((samars) => (
 //         <div key={samars._id}>{samars.name}</div>
 //       ))}
 //     </div>
 //   );
 // };
 // About.title = 'About';
 // export const getServerSideProps = async () => {
 //   try {
 //     console.log('connecting to mongo');
 //     await connectMongo();
 //     console.log('connected to mongo');
 //     console.log('Fetching documents');
 //     const samars = await Samar.find();
 //     console.log('fetched documents');
 //     return {
 //       props: {
 //         samars: JSON.parse(JSON.stringify(samars)),
 //       },
 //     };
 //   } catch (err) {
 //     return {
 //       notFound: true,
 //     };
 //   }
 // };
 // export default About;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-regular-svg-icons");

/***/ }),

/***/ 6466:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3061:
/***/ ((module) => {

"use strict";
module.exports = require("react-animated-checkbox");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967,848], () => (__webpack_exec__(8643)));
module.exports = __webpack_exports__;

})();