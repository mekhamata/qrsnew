(() => {
var exports = {};
exports.id = 190;
exports.ids = [190];
exports.modules = {

/***/ 2560:
/***/ ((module) => {

// Exports
module.exports = {
	"pageCover": "cart_pageCover__tIDE7",
	"coverTitle": "cart_coverTitle__n8ufZ",
	"pageData": "cart_pageData__0H3G1",
	"pageDataIn": "cart_pageDataIn__XGL15",
	"pageNavigator": "cart_pageNavigator__OVQyS",
	"navlink": "cart_navlink__nLoaE",
	"navlink__active": "cart_navlink__active__RB8jU",
	"pageRealData": "cart_pageRealData__s8cas",
	"contentParagraph": "cart_contentParagraph__d5ZJq",
	"contentMainTitle": "cart_contentMainTitle__CH3fE",
	"contentText": "cart_contentText__0Lw50",
	"homeCircleContainer": "cart_homeCircleContainer__iT7ZP",
	"homeCircleCenter": "cart_homeCircleCenter__TvMyY",
	"contactCirclesContainer": "cart_contactCirclesContainer__CT_sZ",
	"contactCirclesItemUL": "cart_contactCirclesItemUL__GywGt",
	"contactCirclesItem": "cart_contactCirclesItem__yP4Po",
	"contactCirclesItemIcon": "cart_contactCirclesItemIcon__er47y",
	"contactCirclesItemIconOut": "cart_contactCirclesItemIconOut__7Bzr8",
	"contactCirclesItemIconIn": "cart_contactCirclesItemIconIn__49ciM",
	"contactCirclesItemIconClass": "cart_contactCirclesItemIconClass__lW1l3",
	"contactCirclesItemText": "cart_contactCirclesItemText__mVbdI",
	"formAndText": "cart_formAndText__VkqTR",
	"footerContainer_in": "cart_footerContainer_in__GVIls",
	"footerForm": "cart_footerForm__be4Ka",
	"footerText": "cart_footerText__XQ5s2",
	"footerTitles": "cart_footerTitles___cmnY",
	"footerInfo": "cart_footerInfo__Friq9",
	"footerSocial": "cart_footerSocial__T_rMp",
	"footerInfoLink": "cart_footerInfoLink__MRxWi",
	"socialIcons": "cart_socialIcons__Q2Z12",
	"footerFormRow": "cart_footerFormRow__At8nZ",
	"footerFormInput": "cart_footerFormInput__nfX0r",
	"footerFormTextArea": "cart_footerFormTextArea__D9ln1",
	"filled": "cart_filled__IJdt3",
	"footerFormTextAreaTitle": "cart_footerFormTextAreaTitle__IFOE3",
	"formSubscription": "cart_formSubscription__fM7oc",
	"formSubmit": "cart_formSubmit___aYLV",
	"contactMap": "cart_contactMap__nuBDJ",
	"contactMapTitle": "cart_contactMapTitle__q8D5C",
	"contactMapFrame": "cart_contactMapFrame__mw0C3",
	"tableContainer": "cart_tableContainer__pfvW6",
	"spacing": "cart_spacing__Bg8XS",
	"tableTitle": "cart_tableTitle__qY2Ls",
	"qtyContainer": "cart_qtyContainer__l5_8V",
	"qtyInput": "cart_qtyInput__TIe1m",
	"qtyBtn": "cart_qtyBtn__vzddk",
	"homeCircleItem": "cart_homeCircleItem__UtS_f"
};


/***/ }),

/***/ 1723:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2560);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_NavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4486);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_iconComponent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4310);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1564);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(validator__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3060);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5848);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_15__]);
react_toastify__WEBPACK_IMPORTED_MODULE_15__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




















function TextInput({ type ="text" , label , name , required =false , value , setter ,  }) {
    // const [value, setValue] = useState("");
    function handleChange(e) {
        setter(e.target.value);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormInput),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                type: type,
                value: value,
                onChange: handleChange,
                name: name,
                required: required
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", {
                className: value && (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().filled),
                htmlFor: name,
                children: label
            })
        ]
    });
}
const Cart = ({ lang  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)([
        "common",
        "contact"
    ]);
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cart.cart);
    const form = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)();
    const table = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        dispatch((0,_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_4__/* .getSiteDataAsync */ .Ah)());
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const siteData = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)(_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_4__/* .showSiteData */ .KE);
    //all serves <--start-->
    const myLoader = ({ src , width , quality  })=>{
        return `https://qrs-global.com/uploads/${src}?w=${width}&q=${quality || 75}`;
    };
    const { 0: from_email , 1: setFromEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: full_name , 1: setFull_name  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: message , 1: setMessage  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: phone , 1: setPhone  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: company , 1: setCompany  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: sendStatus , 1: setSendStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const thetable = table?.current?.innerHTML | "";
    const changeQuantity = (action, itemindex, theqty, dispatch)=>{
        if (action !== "plus" && action !== "minus" && action !== "manual") return;
        let newarr = [
            ...cart
        ];
        let newqty = 0;
        if (action === "plus") {
            newqty = newarr[itemindex].qty + theqty;
        }
        if (action === "minus") {
            newqty = newarr[itemindex].qty - theqty;
        }
        // if (action === "manual") {
        //   newarr[itemindex].qty = theqty;
        // }
        dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_14__/* .setQuantity */ .M$)({
            id: newarr[itemindex].id,
            qty: newqty <= 0 ? 1 : newqty
        }));
    };
    //all serves <--end-->
    const notify = (msg, type)=>{
        react_toastify__WEBPACK_IMPORTED_MODULE_15__.toast.dismiss();
        if (type === "success") {
            return react_toastify__WEBPACK_IMPORTED_MODULE_15__.toast.success(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        } else {
            return react_toastify__WEBPACK_IMPORTED_MODULE_15__.toast.error(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        }
    };
    const sendEmail = async (e, cart)=>{
        e.preventDefault();
        setSendStatus(true);
        const inputData = e.target.elements;
        if (inputData.from_email) {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isEmail(inputData.from_email.value)) {
                console.log("valid email");
            } else {
                // alert("Enter valid Email!");
                notify(`${t("contact:emailerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.full_name) {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isAlpha(inputData.full_name.value, [
                "he"
            ], {
                ignore: " "
            }) || validator__WEBPACK_IMPORTED_MODULE_11___default().isAlpha(inputData.full_name.value, [
                "en-US"
            ], {
                ignore: " "
            })) {
                console.log("valid name");
            } else {
                notify(`${t("contact:fullnameerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.phone && inputData.phone.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isMobilePhone(inputData.phone.value, [
                "he-IL"
            ])) {
                console.log("valid phone");
            } else {
                notify(`${t("contact:phoneerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.message && inputData.message.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.message.value, [
                "he"
            ], {
                ignore: " ,.?:@()[]-_"
            }) || validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.message.value, [
                "en-US"
            ], {
                ignore: " ,.?:@()[]-_"
            })) {
                console.log("valid message");
            } else {
                notify(`${t("contact:messageerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.company && inputData.company.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.company.value, [
                "he"
            ], {
                ignore: " ()-_"
            }) || validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.company.value, [
                "en-US"
            ], {
                ignore: " ()-_"
            })) {
                console.log("valid company");
            } else {
                notify(`${t("contact:companyerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        // create a new dov container
        let div = document.createElement("div");
        // assing your HTML to div's innerHTML
        div.innerHTML = document.getElementById("mytable").innerHTML;
        // get all <a> elements from div
        let elements = div.getElementsByTagName("button");
        // remove all <a> elements
        while(elements[0])elements[0].parentNode.removeChild(elements[0]);
        // get div's innerHTML into a new variable
        const repl = div.innerHTML;
        const templateParams = {
            full_name: inputData.full_name.value,
            phone: inputData.phone.value,
            company: inputData.company.value,
            from_email: inputData.from_email.value,
            message: inputData.message.value + "<br />" + repl
        };
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_10___default().send("service_y0z1qup", "template_bqelwhr", // form.current,
        templateParams, "y9eqDlIW1ZnKzAxVt").then((result)=>{
            notify(`${t("contact:formsuccess")}`, "success");
            setFromEmail("");
            setFull_name("");
            setPhone("");
            setCompany("");
            setMessage("");
            setSendStatus(false);
            dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_14__/* .emptyCart */ .UY)());
        // inputData.from_email.value = "";
        // inputData.full_name.value = "";
        // inputData.phone.value = "";
        // inputData.company.value = "";
        // inputData.message.value = "";
        }, (error)=>{
            setSendStatus(false);
            notify(`${t("contact:formerror")}`, "error");
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_toastify__WEBPACK_IMPORTED_MODULE_15__.ToastContainer, {
                position: "bottom-center",
                autoClose: 3000,
                hideProgressBar: false,
                newestOnTop: false,
                closeOnClick: true,
                pauseOnFocusLoss: true,
                draggable: true,
                pauseOnHover: true,
                theme: "dark"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            siteData?.["Title"],
                            " | ",
                            t("common:shoppingcart")
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageCover",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().pageCover),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    alt: "page cover",
                    src: "/img/contactcover.png",
                    layout: "fill",
                    objectFit: "cover"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageData",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().pageData),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "pageDataIn",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().pageDataIn),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().pageNavigator),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    href: "/",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().navlink),
                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().navlink__active),
                                    title: t("common:home")
                                }),
                                "/",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    href: "/cart",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().navlink),
                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().navlink__active),
                                    title: t("common:shoppingcart")
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().pageRealData),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().contentParagraph),
                                children: cart.length === 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    style: {
                                        fontSize: "20px"
                                    },
                                    children: t("common:cartempty")
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().formAndText),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            id: "footerContainer_in",
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerContainer_in),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    id: "footerForm",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerForm),
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerTitles),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                                                                children: t("common:shoppingcart")
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableContainer),
                                                            ref: table,
                                                            id: "mytable",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("th", {
                                                                                children: t("common:cartproduct")
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("th", {
                                                                                width: "25%",
                                                                                children: t("common:quantity")
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("th", {
                                                                                width: "10%"
                                                                            })
                                                                        ]
                                                                    }),
                                                                    cart?.map((item, index)=>{
                                                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().spacing),
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("td", {
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().tableTitle),
                                                                                            children: item.title
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("td", {
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().qtyContainer),
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().qtyBtn),
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                                                                                        onClick: ()=>changeQuantity("plus", index, 1, dispatch),
                                                                                                        children: "+"
                                                                                                    })
                                                                                                }),
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().qtyInput),
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                                                                        type: "number",
                                                                                                        min: "1",
                                                                                                        max: "9",
                                                                                                        step: "1",
                                                                                                        value: item.qty,
                                                                                                        disabled: true
                                                                                                    })
                                                                                                }),
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().qtyBtn),
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                                                                                        onClick: ()=>{
                                                                                                            changeQuantity("minus", index, 1, dispatch);
                                                                                                        },
                                                                                                        children: "-"
                                                                                                    })
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("td", {
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                            onClick: ()=>dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_14__/* .removeItem */ .cl)(item.id)),
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                                type: "fab",
                                                                                                name: "fa-trash"
                                                                                            })
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            }, index)
                                                                        });
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    id: "footerText",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerText),
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerTitles),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                                                                children: t("common:order")
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerInfo),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                ref: form,
                                                                onSubmit: (e)=>sendEmail(e, cart),
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormRow),
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                type: "input",
                                                                                label: t("common:email"),
                                                                                name: "from_email",
                                                                                setter: setFromEmail,
                                                                                value: from_email
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                type: "input",
                                                                                label: t("common:fullname"),
                                                                                name: "full_name",
                                                                                setter: setFull_name,
                                                                                value: full_name
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormRow),
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                label: t("common:cellphone"),
                                                                                name: "phone",
                                                                                setter: setPhone,
                                                                                value: phone
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                label: t("common:company"),
                                                                                name: "company",
                                                                                setter: setCompany,
                                                                                value: company
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormRow),
                                                                        style: {
                                                                            flexDirection: "column"
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormTextAreaTitle),
                                                                                children: t("common:message")
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormTextArea),
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", {
                                                                                    placeholder: "",
                                                                                    name: "message",
                                                                                    onChange: (e)=>setMessage(e.target.value),
                                                                                    value: message
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().footerFormRow),
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_17___default().formSubmit),
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                                                    type: "hidden",
                                                                                    name: "thetable",
                                                                                    value: thetable
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                                                                    disabled: sendStatus,
                                                                                    children: sendStatus ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                                                        color: "#ffffff",
                                                                                        size: 15,
                                                                                        "aria-label": "Loading Spinner",
                                                                                        "data-testid": "loader"
                                                                                    }) : t("common:send")
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};
// export const getStaticProps = async () => {
//   const res1 = await fetch(
//     'https://qrs-global.com/react/serves/servescat.php?id=5'
//   );
//   const data1 = await res1.json();
//   const res2 = await fetch('https://qrs-global.com/react/serves/serves.php');
//   const data2 = await res2.json();
//   return {
//     props: {
//       servescat: data1,
//       allserves: data2,
//     },
//   };
// };
// Serves.title = 'Serves';
async function getServerSideProps({ locale  }) {
    if (false) {}
    return {
        props: {
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__.serverSideTranslations)(locale ?? "he"),
            lang: locale ?? "he"
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-regular-svg-icons");

/***/ }),

/***/ 6466:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1564:
/***/ ((module) => {

"use strict";
module.exports = require("validator");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967,983,848], () => (__webpack_exec__(1723)));
module.exports = __webpack_exports__;

})();