const Users = () => {
  return <div>admin - users</div>;
};

export default Users;
