(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3899:
/***/ ((module) => {

// Exports
module.exports = {
	"footerContainer": "footer_footerContainer__CfPRK",
	"footerContainer_in": "footer_footerContainer_in__gwixJ",
	"footerForm": "footer_footerForm__wwA_R",
	"footerText": "footer_footerText__5Pgyh",
	"footerTitles": "footer_footerTitles__q4nwW",
	"footerInfo": "footer_footerInfo__gF8oS",
	"footerSocial": "footer_footerSocial__OVzXb",
	"footerInfoLink": "footer_footerInfoLink__8XrSi",
	"socialIcons": "footer_socialIcons__MVyYQ",
	"footerFormRow": "footer_footerFormRow__DvUh2",
	"footerFormInput": "footer_footerFormInput__RTeuY",
	"footerFormTextArea": "footer_footerFormTextArea__Zjt0Z",
	"filled": "footer_filled__r4lr4",
	"footerFormTextAreaTitle": "footer_footerFormTextAreaTitle__C2DP2",
	"formSubscription": "footer_formSubscription__ULNB5",
	"formSubmit": "footer_formSubmit__Z3jgs",
	"hoverlink": "footer_hoverlink__fLis4"
};


/***/ }),

/***/ 4814:
/***/ ((module) => {

// Exports
module.exports = {
	"headerPass": "header_headerPass__SqSvv",
	"headerBlue": "header_headerBlue__XlR7_",
	"headerBlueIn": "header_headerBlueIn__BZblK",
	"menuUl": "header_menuUl__eSzEO",
	"headerAddress": "header_headerAddress__i89t9",
	"headerAddressLink": "header_headerAddressLink__Bt1G2",
	"headerAddressSpan": "header_headerAddressSpan__FgzNM",
	"headerWhite": "header_headerWhite__bXGDg",
	"logoDiv": "header_logoDiv__9xttJ",
	"logoContainer": "header_logoContainer__jVmCp",
	"catalogBtn": "header_catalogBtn__Yl_Ej",
	"catalogBtnIn": "header_catalogBtnIn__8bCj_",
	"catalogBtnInLink": "header_catalogBtnInLink__ovZSd",
	"headerUlComponentContainer": "header_headerUlComponentContainer__pscYP",
	"headerBarIcons": "header_headerBarIcons__SKSTG",
	"headerBarText": "header_headerBarText__aS5_q"
};


/***/ }),

/***/ 171:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "mob_container__qVbZA",
	"mobileMenuOpener": "mob_mobileMenuOpener__JpIMC",
	"mobileMenuOpenerText": "mob_mobileMenuOpenerText__iJbMg",
	"menuOpenerBars": "mob_menuOpenerBars__xlkkK",
	"menuOpenerLogo": "mob_menuOpenerLogo__up3cC",
	"logoDiv": "mob_logoDiv__nSf4j",
	"logoContainer": "mob_logoContainer__mlYVN",
	"catalogBtn": "mob_catalogBtn__jbZk3",
	"catalogBtnIn": "mob_catalogBtnIn__nnM_d",
	"headerUlComponentContainer_closed": "mob_headerUlComponentContainer_closed__qWBhU",
	"slideup": "mob_slideup__Guwfd",
	"headerUlComponentContainer_opened": "mob_headerUlComponentContainer_opened__O9oho",
	"slidedown": "mob_slidedown__KeaO5",
	"headerUlComponentContainer": "mob_headerUlComponentContainer__Wlu8B",
	"headerUlComponent": "mob_headerUlComponent__tKuV3",
	"navlink": "mob_navlink__U3eC_",
	"navlink_active": "mob_navlink_active__Hl4Mt",
	"menu-enter-active": "mob_menu-enter-active__gN44F",
	"menu-leave-active": "mob_menu-leave-active__0_cHG",
	"displaynone": "mob_displaynone__Ir6YO",
	"hoverlink": "mob_hoverlink__AVSEA"
};


/***/ }),

/***/ 9386:
/***/ ((module) => {

// Exports
module.exports = {
	"headerUlComponent": "web_headerUlComponent__r65QR",
	"navlink": "web_navlink__aksbP",
	"navlink_active": "web_navlink_active__h_qPl",
	"subUl": "web_subUl__G3Bk5",
	"subUlRelative": "web_subUlRelative__asj2A",
	"subMenuLink": "web_subMenuLink__f_Qug"
};


/***/ }),

/***/ 1450:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ useHEADER),
/* harmony export */   "q": () => (/* binding */ HEADERContextProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const HEADERContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function HEADERContextProvider({ children  }) {
    const { 0: serves , 1: setServes  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        async function fetchData() {
            const headers = {
                "Content-Type": "application/json"
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`https://qrs-global.com/react/serves/serves.php`, {
                headers
            });
            console.log(data);
            setServes(data.allserves);
        }
        fetchData();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(HEADERContext.Provider, {
        value: {
            serves
        },
        children: children
    });
}
function useHEADER() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(HEADERContext);
    if (context === undefined) {
        throw new Error("Context must be used within a Provider");
    }
    return context;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3333:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3899);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _NavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var _iconComponent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4310);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4486);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1564);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(validator__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3060);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_11__]);
react_toastify__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
















// import FloatingLabel from 'react-bootstrap/FloatingLabel';
// import Form from 'react-bootstrap/Form';
function TextInput({ type ="text" , label , name , required =false , value , setter ,  }) {
    // const [value, setValue] = useState("");
    function handleChange(e) {
        setter(e.target.value);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormInput),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                type: type,
                value: value,
                onChange: handleChange,
                name: name,
                required: required
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", {
                className: value && (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().filled),
                htmlFor: name,
                children: label
            })
        ]
    });
}
const TheToast = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_toastify__WEBPACK_IMPORTED_MODULE_11__.ToastContainer, {
        position: "bottom-center",
        autoClose: 3000,
        hideProgressBar: false,
        newestOnTop: false,
        closeOnClick: true,
        pauseOnFocusLoss: true,
        draggable: true,
        pauseOnHover: true,
        theme: "dark"
    });
};
const Footer = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        dispatch((0,_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__/* .getSiteDataAsync */ .Ah)());
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const siteData = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)(_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__/* .showSiteData */ .KE);
    // const { t } = useTranslation(["common", "contact"]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const form = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const { 0: from_email , 1: setFromEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: full_name , 1: setFull_name  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: message , 1: setMessage  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: phone , 1: setPhone  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: company , 1: setCompany  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: sendStatus , 1: setSendStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)([
        "common",
        "contact"
    ]);
    //all serves <--end-->
    const notify = (msg, type)=>{
        react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.dismiss();
        if (type === "success") {
            return react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.success(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        } else {
            return react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        }
    };
    const sendEmail = async (e)=>{
        e.preventDefault();
        setSendStatus(true);
        const inputData = e.target.elements;
        if (inputData.from_email) {
            if (validator__WEBPACK_IMPORTED_MODULE_10___default().isEmail(inputData.from_email.value)) {
                console.log("valid email");
            } else {
                // alert("Enter valid Email!");
                notify(`${t("contact:emailerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.full_name) {
            if (validator__WEBPACK_IMPORTED_MODULE_10___default().isAlpha(inputData.full_name.value, [
                "he"
            ], {
                ignore: " "
            }) || validator__WEBPACK_IMPORTED_MODULE_10___default().isAlpha(inputData.full_name.value, [
                "en-US"
            ], {
                ignore: " "
            })) {
                console.log("valid name");
            } else {
                notify(`${t("contact:fullnameerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.phone && inputData.phone.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_10___default().isMobilePhone(inputData.phone.value, [
                "he-IL"
            ])) {
                console.log("valid phone");
            } else {
                notify(`${t("contact:phoneerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.message && inputData.message.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_10___default().isAlphanumeric(inputData.message.value, [
                "he"
            ], {
                ignore: " ,.?:@()[]-_"
            }) || validator__WEBPACK_IMPORTED_MODULE_10___default().isAlphanumeric(inputData.message.value, [
                "en-US"
            ], {
                ignore: " ,.?:@()[]-_"
            })) {
                console.log("valid message");
            } else {
                notify(`${t("contact:messageerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.company && inputData.company.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_10___default().isAlphanumeric(inputData.company.value, [
                "he"
            ], {
                ignore: " ()-_"
            }) || validator__WEBPACK_IMPORTED_MODULE_10___default().isAlphanumeric(inputData.company.value, [
                "en-US"
            ], {
                ignore: " ()-_"
            })) {
                console.log("valid company");
            } else {
                notify(`${t("contact:companyerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_9___default().sendForm("service_y0z1qup", "template_bqelwhr", form.current, "y9eqDlIW1ZnKzAxVt").then((result)=>{
            notify(`${t("contact:formsuccess")}`, "success");
            setFromEmail("");
            setFull_name("");
            setPhone("");
            setCompany("");
            setMessage("");
            setSendStatus(false);
        // inputData.from_email.value = "";
        // inputData.full_name.value = "";
        // inputData.phone.value = "";
        // inputData.company.value = "";
        // inputData.message.value = "";
        }, (error)=>{
            setSendStatus(false);
            notify(`${t("contact:formerror")}`, "error");
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("footer", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            id: "footerContainer",
            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerContainer),
            children: router?.pathname !== "/contact" && router?.pathname !== "/cart" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                id: "footerContainer_in",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerContainer_in),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "footerForm",
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerForm),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerTitles),
                                children: t("common:contactus")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                ref: form,
                                onSubmit: sendEmail,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormRow),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                type: "input",
                                                label: t("common:email"),
                                                name: "from_email",
                                                setter: setFromEmail,
                                                value: from_email
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                type: "input",
                                                label: t("common:fullname"),
                                                name: "full_name",
                                                setter: setFull_name,
                                                value: full_name
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormRow),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                label: t("common:phone"),
                                                name: "phone",
                                                setter: setPhone,
                                                value: phone
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                label: t("common:company"),
                                                name: "company",
                                                setter: setCompany,
                                                value: company
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormRow),
                                        style: {
                                            flexDirection: "column"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormTextAreaTitle),
                                                children: t("common:message")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormTextArea),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", {
                                                    placeholder: "",
                                                    name: "message",
                                                    onChange: (e)=>setMessage(e.target.value),
                                                    value: message
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerFormRow),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().formSubscription),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                            type: "checkbox"
                                                        }),
                                                        t("contact:interestedinmailsub")
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().formSubmit),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                                    disabled: sendStatus,
                                                    children: sendStatus ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        color: "#ffffff",
                                                        size: 15,
                                                        "aria-label": "Loading Spinner",
                                                        "data-testid": "loader"
                                                    }) : t("common:send")
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "footerText",
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerText),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerTitles),
                                children: "קיו אר אס מדיקל"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerInfo),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                target: "_blank",
                                                href: siteData?.["wazelink"],
                                                title: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_15__/* .whatLanguage */ .V)(router.locale, siteData, "address"),
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerInfoLink)
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                t("common:phone"),
                                                ".",
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: `tel:${siteData?.["phone"]}`,
                                                    title: siteData?.["phone"],
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerInfoLink)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                t("common:cellphone"),
                                                ".",
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: `tel:${siteData?.["phone2"]}`,
                                                    title: siteData?.["phone2"],
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerInfoLink)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                t("common:cellphone"),
                                                ".",
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: `tel:${siteData?.["phone3"]}`,
                                                    title: siteData?.["phone3"],
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerInfoLink)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: `mailto:${siteData?.["email"]}`,
                                                title: siteData?.["email"],
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerInfoLink)
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().footerSocial),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                target: "_blank",
                                                href: siteData?.["linkedin"],
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().socialIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-brands fa-linkedin"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                target: "_blank",
                                                href: siteData?.["facebook"],
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().socialIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-brands fa-square-facebook"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                target: "_blank",
                                                href: siteData?.["utube"],
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_14___default().socialIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-brands fa-youtube"
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TheToast, {})
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5314:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _header_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4814);
/* harmony import */ var _header_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_header_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mob__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6978);
/* harmony import */ var _web__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6647);
/* harmony import */ var _NavLink__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1967);
/* harmony import */ var _store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4486);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _utils_helperFunctions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8365);
/* harmony import */ var _iconComponent__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4310);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_web__WEBPACK_IMPORTED_MODULE_5__]);
_web__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














function useWindowSize() {
    const { 0: size , 1: setSize  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([
        0,
        0
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useLayoutEffect)(()=>{
        function updateSize() {
            setSize([
                window.innerWidth,
                window.innerHeight
            ]);
        }
        window.addEventListener("resize", updateSize);
        updateSize();
        return ()=>window.removeEventListener("resize", updateSize);
    }, []);
    return size;
}
const Header = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        dispatch((0,_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__/* .getSiteDataAsync */ .Ah)());
    // dispatch(getServesAsync());
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const { 0: mobileView , 1: setMobileView  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [width, height] = useWindowSize();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useLayoutEffect)(()=>{
        setMobileView(width <= 991);
    }, [
        width,
        mobileView
    ]);
    const siteData = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)(_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__/* .showSiteData */ .KE);
    // const servesData = useSelector(showServesData);
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)([
        "common"
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("header", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            id: "headerPass",
            className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerPass),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "headerBlue",
                    className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBlue),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            id: "headerBlueIn",
                            className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBlueIn),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                id: "headerAddress",
                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddress),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_NavLink__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        href: `tel:${siteData?.["phone"]}`,
                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressLink),
                                        activeClassName: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().navlink_active),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarText),
                                                children: [
                                                    siteData?.["phone"],
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressSpan),
                                                        children: "|"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-solid fa-phone"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_NavLink__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        href: `tel:${siteData?.["phone2"]}`,
                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressLink),
                                        activeClassName: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().navlink_active),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarText),
                                                children: [
                                                    siteData?.["phone2"],
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressSpan),
                                                        children: "|"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-solid fa-mobile"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_NavLink__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        href: `tel:${siteData?.["phone3"]}`,
                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressLink),
                                        activeClassName: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().navlink_active),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarText),
                                                children: [
                                                    siteData?.["phone3"],
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressSpan),
                                                        children: "|"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-solid fa-mobile"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_NavLink__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        href: `mailto:${siteData?.["email"]}`,
                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressLink),
                                        activeClassName: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().navlink_active),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarText),
                                                children: [
                                                    siteData?.["email"] + " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressSpan),
                                                        children: "|"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerBarIcons),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                    type: "fab",
                                                    name: "fa-solid fa-envelope"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        target: "_blank",
                                        href: siteData?.["wazelink"],
                                        className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerAddressLink),
                                        activeClassName: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().navlink_active),
                                        children: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_13__/* .whatLanguage */ .V)(router.locale, siteData, "address")
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            id: "menuUl",
                            className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().menuUl),
                            children: mobileView ? // <MobHeader header_allserves={servesData} />
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mob__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}) : // <WebHeader header_allserves={servesData} />
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_web__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                        })
                    ]
                }),
                !mobileView && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "headerWhite",
                    className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().headerWhite),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            id: "catalogBtn",
                            className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().catalogBtn),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                id: "catalogBtnIn",
                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().catalogBtnIn),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    href: "",
                                    title: t("common:catalog"),
                                    className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().catalogBtnInLink)
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            id: "logoDiv",
                            className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().logoDiv),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_header_module_css__WEBPACK_IMPORTED_MODULE_12___default().logoContainer),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/img/logo.png",
                                    width: "154",
                                    height: "82",
                                    alt: "logo",
                                    layout: "responsive",
                                    priority: true
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(171);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6466);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _iconComponent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4310);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);












const MobHeader = ()=>{
    const { 0: showNav , 1: setShowNav  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    let classlist = "classlist";
    const toggleMenu = ()=>{
        setShowNav(!showNav);
    };
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)([
        "common"
    ]);
    //close menu on every router change
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setShowNav(false);
    }, [
        router.pathname
    ]);
    const cartItemsNumber = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)((state)=>state.cart.cart).length | 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        id: "container",
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().container),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                id: "mobileMenuOpener",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().mobileMenuOpener),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        id: "menuOpenerBars",
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().menuOpenerBars),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, {
                            icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faBars,
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().mobileMenuOpenerText),
                            onClick: toggleMenu
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        id: "menuOpenerLogo",
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().menuOpenerLogo),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            id: "logoDiv",
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().logoDiv),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    id: "catalogBtn",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().catalogBtn),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        id: "catalogBtnIn",
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().catalogBtnIn),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                            href: "",
                                            alt: "",
                                            title: "",
                                            children: "קטלוג"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().logoContainer),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: "/img/logo.png",
                                        width: "154",
                                        height: "82",
                                        alt: "logo",
                                        layout: "responsive",
                                        priority: true
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "headerUlComponentContainer",
                className: `${showNav ? (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().headerUlComponentContainer_opened) : (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().headerUlComponentContainer)}`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    id: "headerUlComponent",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().headerUlComponent),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/en",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: "EN"
                                })
                            })
                        }, 1),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: t("common:main")
                                })
                            })
                        }, 2),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/about",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: t("common:about")
                                })
                            })
                        }, 3),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/serves",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: t("common:serves")
                                })
                            })
                        }, 4),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/products",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: t("common:products")
                                })
                            })
                        }, 5),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/contact",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: t("common:contactus")
                                })
                            })
                        }, 6),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/cart",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_10___default().navlink),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            type: "fab",
                                            name: "fa-shopping-cart"
                                        }),
                                        " ",
                                        cartItemsNumber > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                "(",
                                                cartItemsNumber,
                                                ")"
                                            ]
                                        })
                                    ]
                                })
                            })
                        }, 7)
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobHeader);


/***/ }),

/***/ 6647:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _NavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9386);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1450);
/* harmony import */ var _utils_helperFunctions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8365);
/* harmony import */ var _iconComponent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4310);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_6__]);
_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const WebHeader = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)([
        "common"
    ]);
    const { serves  } = (0,_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_6__/* .useHEADER */ .B)();
    const cartItemsNumber = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.cart.cart).length | 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        id: "headerUlComponent",
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().headerUlComponent),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: router.asPath,
                    locale: router.locale === "he" ? "en" : "he",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                        children: router.locale === "he" ? "EN" : "עב"
                    })
                })
            }, 1),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    title: t("common:main"),
                    href: "/",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink_active)
                })
            }, 2),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    title: t("common:about"),
                    href: "/about",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink_active)
                })
            }, 3),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    title: t("common:serves"),
                    href: "/serves",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink_active),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().subUl),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().subUlRelative),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("ul", {
                                children: serves?.map((item)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_10__/* .whatLanguage */ .V)(router.locale, item, "title"),
                                            href: `/serves/${item.id}`,
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().subMenuLink)
                                        })
                                    }, item.id);
                                })
                            })
                        })
                    })
                })
            }, 4),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    title: t("common:products"),
                    href: "/products",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink_active)
                })
            }, 5),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    title: t("common:contactus"),
                    href: "/contact",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink_active)
                })
            }, 6),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    href: "/cart",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink),
                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_9___default().navlink_active),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_iconComponent__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            type: "fab",
                            name: "fa-shopping-cart"
                        }),
                        " ",
                        cartItemsNumber > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                "(",
                                cartItemsNumber,
                                ")"
                            ]
                        })
                    ]
                })
            }, 7)
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WebHeader);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2469:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _header_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5314);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3333);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header_header__WEBPACK_IMPORTED_MODULE_1__, _footer__WEBPACK_IMPORTED_MODULE_2__]);
([_header_header__WEBPACK_IMPORTED_MODULE_1__, _footer__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const Layout = ({ children  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        dir: router.locale === "he" ? "rtl" : "ltr",
        style: {
            overflowX: "hidden"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_header_header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("main", {
                children: children
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fortawesome_fontawesome_svg_core_styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5800);
/* harmony import */ var _fortawesome_fontawesome_svg_core_styles_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_svg_core_styles_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3195);
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2469);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1676);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4161);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1127);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var nextjs_progressbar_spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5025);
/* harmony import */ var nextjs_progressbar_spinner__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar_spinner__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1450);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout__WEBPACK_IMPORTED_MODULE_3__, _components_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_12__]);
([_components_layout__WEBPACK_IMPORTED_MODULE_3__, _components_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


 // import Font Awesome CSS

_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_2__.config.autoAddCss = false; // Tell Font Awesome to skip adding the CSS automatically since it's being imported above











// function Loading() {
//   const router = useRouter();
//   const [loading, setLoading] = useState(false);
//   useEffect(() => {
//     const handleStart = (url) => url !== router.asPath && setLoading(true);
//     const handleCompelete = (url) =>
//       url === router.asPath &&
//       setTimeout(() => {
//         setLoading(false);
//       }, 2000);
//     router.events.on("routeChangeStart", handleStart);
//     router.events.on("routeChangeComplete", handleCompelete);
//     router.events.on("routeChangeError", handleCompelete);
//     return () => {
//       router.events.off("routeChangeStart", handleStart);
//       router.events.off("routeChangeComplete", handleCompelete);
//       router.events.off("routeChangeError", handleCompelete);
//     };
//   });
//   return (
//     loading && (
//       <div className="spinner-wrapper" style={{ zIndex: 5 }}>
//         <div className="spinner"></div>
//       </div>
//     )
//   );
// }
// let persistor = persistStore(store);
function MyApp({ Component , pageProps  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        router.isReady && setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_redux__WEBPACK_IMPORTED_MODULE_7__.Provider, {
            store: _store_index__WEBPACK_IMPORTED_MODULE_8__/* .store */ .h,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_10__.PersistGate, {
                loading: null,
                persistor: _store_index__WEBPACK_IMPORTED_MODULE_8__/* .persistor */ .D,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_contexts_HeaderContext__WEBPACK_IMPORTED_MODULE_12__/* .HEADERContextProvider */ .q, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_layout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "spinner-wrapper",
                                    style: {
                                        zIndex: 5
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(nextjs_progressbar_spinner__WEBPACK_IMPORTED_MODULE_11__.NextProgressbarSpinner, {
                                        NextNProgressProps: {
                                            color: "#61DCFB",
                                            progressBarVisibility: "hidden",
                                            startPosition: 0.3,
                                            stopDelayMs: 200,
                                            height: 1,
                                            showOnShallow: true,
                                            options: {
                                                showSpinner: true
                                            }
                                        },
                                        spinnerType: "CircleLoader",
                                        spinnerProps: {
                                            size: "2rem",
                                            color: "#61DCFB"
                                        }
                                    })
                                })
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Component, {
                                ...pageProps
                            })
                        })
                    })
                })
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.appWithTranslation)(MyApp));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1676:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "D": () => (/* binding */ persistor),
  "h": () => (/* binding */ store)
});

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: ./store/slices/generalSlice.js
var generalSlice = __webpack_require__(4486);
// EXTERNAL MODULE: ./store/slices/cartSlice.js
var cartSlice = __webpack_require__(5848);
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
// EXTERNAL MODULE: external "redux-persist"
var external_redux_persist_ = __webpack_require__(4161);
;// CONCATENATED MODULE: ./store/index.js





const persistConfig = {
    key: "root",
    version: 1,
    storage: (storage_default())
};
const reducer = (0,toolkit_.combineReducers)({
    generaldata: generalSlice/* default */.ZP,
    cart: cartSlice/* cartReducer */.C$
});
const persistedReducer = (0,external_redux_persist_.persistReducer)(persistConfig, reducer);
// config the store
const store = (0,toolkit_.configureStore)({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: {
                ignoredActions: [
                    external_redux_persist_.FLUSH,
                    external_redux_persist_.REHYDRATE,
                    external_redux_persist_.PAUSE,
                    external_redux_persist_.PERSIST,
                    external_redux_persist_.PURGE,
                    external_redux_persist_.REGISTER
                ]
            }
        })
});
const persistor = (0,external_redux_persist_.persistStore)(store); // export const persistor = persistStore(store);


/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 5800:
/***/ (() => {



/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-regular-svg-icons");

/***/ }),

/***/ 6466:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 5025:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar-spinner");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4161:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ 1127:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 1564:
/***/ ((module) => {

"use strict";
module.exports = require("validator");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967,983,848], () => (__webpack_exec__(8510)));
module.exports = __webpack_exports__;

})();