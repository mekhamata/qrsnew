(() => {
var exports = {};
exports.id = 335;
exports.ids = [335];
exports.modules = {

/***/ 9514:
/***/ ((module) => {

// Exports
module.exports = {
	"pageCover": "contact_pageCover__9dSSv",
	"coverTitle": "contact_coverTitle___F8LV",
	"pageData": "contact_pageData__tTDxZ",
	"pageDataIn": "contact_pageDataIn__2zRUM",
	"pageNavigator": "contact_pageNavigator__Sc4ko",
	"navlink": "contact_navlink__zyODF",
	"navlink__active": "contact_navlink__active__QnQ0l",
	"pageRealData": "contact_pageRealData__s_kNm",
	"contentParagraph": "contact_contentParagraph__V4CAj",
	"contentMainTitle": "contact_contentMainTitle__M585C",
	"contentText": "contact_contentText__jmi_j",
	"homeCircleContainer": "contact_homeCircleContainer__I987C",
	"homeCircleCenter": "contact_homeCircleCenter__FNgwQ",
	"contactCirclesContainer": "contact_contactCirclesContainer__GwMe7",
	"contactCirclesItemUL": "contact_contactCirclesItemUL__Q6NiA",
	"contactCirclesItem": "contact_contactCirclesItem__5jq0l",
	"contactCirclesItemIcon": "contact_contactCirclesItemIcon__I_RNm",
	"contactCirclesItemIconOut": "contact_contactCirclesItemIconOut__ff0Ql",
	"contactCirclesItemIconIn": "contact_contactCirclesItemIconIn__814TP",
	"contactCirclesItemIconClass": "contact_contactCirclesItemIconClass__YILur",
	"contactCirclesItemText": "contact_contactCirclesItemText__T5eNt",
	"formAndText": "contact_formAndText___OyU5",
	"footerContainer_in": "contact_footerContainer_in__gyCoL",
	"footerForm": "contact_footerForm__pz8Ci",
	"footerText": "contact_footerText__lSkNq",
	"footerTitles": "contact_footerTitles__aH3dw",
	"footerInfo": "contact_footerInfo__PFrdp",
	"footerSocial": "contact_footerSocial__y8lL9",
	"footerInfoLink": "contact_footerInfoLink__bwH_C",
	"socialIcons": "contact_socialIcons__mCIPw",
	"footerFormRow": "contact_footerFormRow__kFjS8",
	"footerFormInput": "contact_footerFormInput__hq3E2",
	"footerFormTextArea": "contact_footerFormTextArea__1tVLA",
	"filled": "contact_filled__RZTVY",
	"footerFormTextAreaTitle": "contact_footerFormTextAreaTitle___CUe0",
	"formSubscription": "contact_formSubscription__Bv6Bx",
	"formSubmit": "contact_formSubmit__cMRuo",
	"contactMap": "contact_contactMap__lp_E_",
	"contactMapTitle": "contact_contactMapTitle__OxSi5",
	"contactMapFrame": "contact_contactMapFrame__G3D0H",
	"homeCircleItem": "contact_homeCircleItem__5y_Ya"
};


/***/ }),

/***/ 4695:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9514);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_NavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4486);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_iconComponent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4310);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1564);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(validator__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3060);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_12__]);
react_toastify__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



















function TextInput({ type ="text" , label , name , required =false , value , setter ,  }) {
    // const [value, setValue] = useState("");
    function handleChange(e) {
        setter(e.target.value);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormInput),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                type: type,
                value: value,
                onChange: handleChange,
                name: name,
                required: required
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", {
                className: value && (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().filled),
                htmlFor: name,
                children: label
            })
        ]
    });
}
const Contact = ({ lang  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_14__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)([
        "common",
        "contact"
    ]);
    const form = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        dispatch((0,_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_4__/* .getSiteDataAsync */ .Ah)());
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const siteData = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)(_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_4__/* .showSiteData */ .KE);
    //all serves <--start-->
    const myLoader = ({ src , width , quality  })=>{
        return `https://qrs-global.com/uploads/${src}?w=${width}&q=${quality || 75}`;
    };
    const { 0: from_email , 1: setFromEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: full_name , 1: setFull_name  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: message , 1: setMessage  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: phone , 1: setPhone  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: company , 1: setCompany  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: sendStatus , 1: setSendStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    //all serves <--end-->
    const notify = (msg, type)=>{
        react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.dismiss();
        if (type === "success") {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.success(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        } else {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.error(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        }
    };
    const sendEmail = async (e)=>{
        e.preventDefault();
        setSendStatus(true);
        const inputData = e.target.elements;
        if (inputData.from_email) {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isEmail(inputData.from_email.value)) {
                console.log("valid email");
            } else {
                // alert("Enter valid Email!");
                notify(`${t("contact:emailerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.full_name) {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isAlpha(inputData.full_name.value, [
                "he"
            ], {
                ignore: " "
            }) || validator__WEBPACK_IMPORTED_MODULE_11___default().isAlpha(inputData.full_name.value, [
                "en-US"
            ], {
                ignore: " "
            })) {
                console.log("valid name");
            } else {
                notify(`${t("contact:fullnameerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.phone && inputData.phone.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isMobilePhone(inputData.phone.value, [
                "he-IL"
            ])) {
                console.log("valid phone");
            } else {
                notify(`${t("contact:phoneerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.message && inputData.message.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.message.value, [
                "he"
            ], {
                ignore: " ,.?:@()[]-_"
            }) || validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.message.value, [
                "en-US"
            ], {
                ignore: " ,.?:@()[]-_"
            })) {
                console.log("valid message");
            } else {
                notify(`${t("contact:messageerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.company && inputData.company.value.trim() !== "") {
            if (validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.company.value, [
                "he"
            ], {
                ignore: " ()-_"
            }) || validator__WEBPACK_IMPORTED_MODULE_11___default().isAlphanumeric(inputData.company.value, [
                "en-US"
            ], {
                ignore: " ()-_"
            })) {
                console.log("valid company");
            } else {
                notify(`${t("contact:companyerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_10___default().sendForm("service_y0z1qup", "template_bqelwhr", form.current, "y9eqDlIW1ZnKzAxVt").then((result)=>{
            notify(`${t("contact:formsuccess")}`, "success");
            setFromEmail("");
            setFull_name("");
            setPhone("");
            setCompany("");
            setMessage("");
            setSendStatus(false);
        // inputData.from_email.value = "";
        // inputData.full_name.value = "";
        // inputData.phone.value = "";
        // inputData.company.value = "";
        // inputData.message.value = "";
        }, (error)=>{
            setSendStatus(false);
            notify(`${t("contact:formerror")}`, "error");
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_toastify__WEBPACK_IMPORTED_MODULE_12__.ToastContainer, {
                position: "bottom-center",
                autoClose: 3000,
                hideProgressBar: false,
                newestOnTop: false,
                closeOnClick: true,
                pauseOnFocusLoss: true,
                draggable: true,
                pauseOnHover: true,
                theme: "dark"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            siteData?.["Title"],
                            " | ",
                            t("common:contactus")
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageCover",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().pageCover),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    alt: "page cover",
                    src: "/img/contactcover.png",
                    layout: "fill",
                    objectFit: "cover"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageData",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().pageData),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "pageDataIn",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().pageDataIn),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().pageNavigator),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    href: "/",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().navlink),
                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().navlink__active),
                                    title: t("common:home")
                                }),
                                "/",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    href: "/contact",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().navlink),
                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().navlink__active),
                                    title: t("common:contactus")
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().pageRealData),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contentParagraph),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    id: "homeCircleContainer",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().homeCircleContainer),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        id: "homeCircleCenter",
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().homeCircleCenter),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesContainer),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemUL),
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItem),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: `tel:${siteData?.["phone"]}`,
                                                                className: "",
                                                                activeClassName: "",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIcon),
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconOut),
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconIn),
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                    type: "fab",
                                                                                    name: "fa-solid fa-phone-volume",
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconClass)
                                                                                })
                                                                            })
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemText),
                                                                        children: siteData?.["phone"]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItem),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: `tel:${siteData?.["phone2"]}`,
                                                                className: "",
                                                                activeClassName: "",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIcon),
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconOut),
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconIn),
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                    type: "fab",
                                                                                    name: "fa-solid fa-phone-volume",
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconClass)
                                                                                })
                                                                            })
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemText),
                                                                        children: siteData?.["phone2"]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItem),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: `tel:${siteData?.["phone3"]}`,
                                                                className: "",
                                                                activeClassName: "",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIcon),
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconOut),
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconIn),
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                    type: "fab",
                                                                                    name: "fa-solid fa-phone-volume",
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconClass)
                                                                                })
                                                                            })
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemText),
                                                                        children: siteData?.["phone3"]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItem),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: `mailto:${siteData?.["email"]}`,
                                                                className: "",
                                                                activeClassName: "",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIcon),
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconOut),
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconIn),
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                    type: "fab",
                                                                                    name: "fa-solid fa-envelope-open",
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemIconClass)
                                                                                })
                                                                            })
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactCirclesItemText),
                                                                        children: siteData?.["email"]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().formAndText),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    id: "footerContainer_in",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerContainer_in),
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            id: "footerForm",
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerForm),
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerTitles),
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                                                                        children: t("common:contactus")
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                    ref: form,
                                                                    onSubmit: sendEmail,
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormRow),
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                    type: "input",
                                                                                    label: t("common:email"),
                                                                                    name: "from_email",
                                                                                    setter: setFromEmail,
                                                                                    value: from_email
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                    type: "input",
                                                                                    label: t("common:fullname"),
                                                                                    name: "full_name",
                                                                                    setter: setFull_name,
                                                                                    value: full_name
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormRow),
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                    label: t("common:cellphone"),
                                                                                    name: "phone",
                                                                                    setter: setPhone,
                                                                                    value: phone
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TextInput, {
                                                                                    label: t("common:company"),
                                                                                    name: "company",
                                                                                    setter: setCompany,
                                                                                    value: company
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormRow),
                                                                            style: {
                                                                                flexDirection: "column"
                                                                            },
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormTextAreaTitle),
                                                                                    children: t("common:message")
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormTextArea),
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", {
                                                                                        placeholder: "",
                                                                                        name: "message",
                                                                                        onChange: (e)=>setMessage(e.target.value),
                                                                                        value: message
                                                                                    })
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerFormRow),
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().formSubscription),
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                        children: [
                                                                                            " ",
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                                                                type: "checkbox"
                                                                                            }),
                                                                                            t("contact:interestedinmailsub")
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().formSubmit),
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                                                                        disabled: sendStatus,
                                                                                        children: sendStatus ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                                                            color: "#ffffff",
                                                                                            size: 15,
                                                                                            "aria-label": "Loading Spinner",
                                                                                            "data-testid": "loader"
                                                                                        }) : t("common:send")
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            id: "footerText",
                                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerText),
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerTitles),
                                                                    children: siteData?.["Title"]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerInfo),
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                    target: "_blank",
                                                                                    href: siteData?.["wazelink"],
                                                                                    title: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, siteData, "address"),
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerInfoLink)
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                                                children: [
                                                                                    t("common:phone"),
                                                                                    ".",
                                                                                    " ",
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: `tel:${siteData?.["phone"]}`,
                                                                                        title: siteData?.["phone"],
                                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerInfoLink)
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                                                children: [
                                                                                    t("common:cellphone"),
                                                                                    ".",
                                                                                    " ",
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: `tel:${siteData?.["phone2"]}`,
                                                                                        title: siteData?.["phone2"],
                                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerInfoLink)
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                                                children: [
                                                                                    t("common:cellphone"),
                                                                                    ".",
                                                                                    " ",
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: `tel:${siteData?.["phone3"]}`,
                                                                                        title: siteData?.["phone3"],
                                                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerInfoLink)
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                    href: `mailto:${siteData?.["email"]}`,
                                                                                    title: siteData?.[0]?.["email"],
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerInfoLink)
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().footerSocial),
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                    target: "_blank",
                                                                                    href: siteData?.["linkedin"],
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().socialIcons),
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                        type: "fab",
                                                                                        name: "fa-brands fa-linkedin"
                                                                                    })
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                    target: "_blank",
                                                                                    href: siteData?.["facebook"],
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().socialIcons),
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                        type: "fab",
                                                                                        name: "fa-brands fa-square-facebook"
                                                                                    })
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                    target: "_blank",
                                                                                    href: siteData?.["utube"],
                                                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().socialIcons),
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                                        type: "fab",
                                                                                        name: "fa-brands fa-youtube"
                                                                                    })
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactMap),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactMapTitle),
                                                        children: t("common:map")
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_16___default().contactMapFrame),
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("iframe", {
                                                            src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3345.47031753989!2d35.27621428445091!3d33.017737578978775!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151c2dec8ec81c1d%3A0x928a13de582e4400!2sQrs%20global!5e0!3m2!1siw!2sil!4v1675347873797!5m2!1siw!2sil",
                                                            style: {
                                                                border: 0,
                                                                width: "100%",
                                                                height: "100%"
                                                            },
                                                            allowFullScreen: "",
                                                            loading: "lazy",
                                                            referrerPolicy: "no-referrer-when-downgrade"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};
// export const getStaticProps = async () => {
//   const res1 = await fetch(
//     'https://qrs-global.com/react/serves/servescat.php?id=5'
//   );
//   const data1 = await res1.json();
//   const res2 = await fetch('https://qrs-global.com/react/serves/serves.php');
//   const data2 = await res2.json();
//   return {
//     props: {
//       servescat: data1,
//       allserves: data2,
//     },
//   };
// };
// Serves.title = 'Serves';
async function getServerSideProps({ locale  }) {
    if (false) {}
    return {
        props: {
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__.serverSideTranslations)(locale ?? "he"),
            lang: locale ?? "he"
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-regular-svg-icons");

/***/ }),

/***/ 6466:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1564:
/***/ ((module) => {

"use strict";
module.exports = require("validator");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967,983], () => (__webpack_exec__(4695)));
module.exports = __webpack_exports__;

})();