"use strict";
exports.id = 486;
exports.ids = [486];
exports.modules = {

/***/ 4486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ah": () => (/* binding */ getSiteDataAsync),
/* harmony export */   "KE": () => (/* binding */ showSiteData),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports generalSlice, getSiteData */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const axios = __webpack_require__(2167);
const THEAPI = `${"https://qrs-global.com"}/react/general/index.php`;
// create a slice
const generalSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "siteData",
    initialState: {
        sitedata: []
    },
    reducers: {
        getSiteData: (state, action)=>{
            state.sitedata = action.payload;
        }
    }
});
const getSiteDataAsync = ()=>async (dispatch)=>{
        try {
            const headers = {
                "Content-Type": "application/json"
            };
            const response = await axios.get(THEAPI, {
                headers
            });
            dispatch(getSiteData(response.data["data"]));
        } catch (err) {
            throw new Error(err);
        }
    };
// export const getServesAsync = () => async (dispatch) => {
//   try {
//     const headers = {
//       "Content-Type": "application/json",
//     };
//     const response = await axios.get(
//       "https://qrs-global.com/react/serves/serves.php",
//       { headers }
//     );
//     dispatch(getServesData(response.data.allserves));
//   } catch (err) {
//     throw new Error(err);
//   }
// };
// export const { getSiteData, getServesData } = generalSlice.actions;
const { getSiteData  } = generalSlice.actions;
const showSiteData = (state)=>state.generaldata.sitedata;
// export const showServesData = (state) => state.generaldata.serves;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (generalSlice.reducer);


/***/ })

};
;