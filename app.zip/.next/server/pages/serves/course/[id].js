(() => {
var exports = {};
exports.id = 644;
exports.ids = [644];
exports.modules = {

/***/ 4601:
/***/ ((module) => {

// Exports
module.exports = {
	"pageCover": "course_pageCover__vF0SM",
	"pageData": "course_pageData__wom3Y",
	"pageDataInContainer": "course_pageDataInContainer__ZNCld",
	"courseInfoContainer": "course_courseInfoContainer__qtu26",
	"courseInfoTitle": "course_courseInfoTitle__m8S0m",
	"contentMainTitle_copy": "course_contentMainTitle_copy__4zYII",
	"titleIconContainer": "course_titleIconContainer__OSwjJ",
	"titleIcon": "course_titleIcon__3gD__",
	"courseInfoNav": "course_courseInfoNav__HVL1u",
	"navDataDiv": "course_navDataDiv__SHu52",
	"pageDataIn": "course_pageDataIn__FKFFu",
	"productsContainer": "course_productsContainer__KELAP",
	"filterContainer": "course_filterContainer__rPj7g",
	"filterContainerIn": "course_filterContainerIn__o1CbN",
	"filterCircle": "course_filterCircle__O13bL",
	"filterCircleIn": "course_filterCircleIn__B7kX_",
	"productsHeader": "course_productsHeader__bSrsx",
	"productsHeaderDead": "course_productsHeaderDead__KLTg_",
	"productsHeaderActive": "course_productsHeaderActive__q0OcG",
	"productsHeaderActiveTitle": "course_productsHeaderActiveTitle__0bAD8",
	"productsHeaderActiveNav": "course_productsHeaderActiveNav__p_Eyf",
	"pageNavigator": "course_pageNavigator__JJBHG",
	"navlink": "course_navlink__ZwuJe",
	"navlink__active": "course_navlink__active__uSbjT",
	"productsList": "course_productsList__w8idi",
	"productsListIn": "course_productsListIn__woz1F",
	"productsListUl": "course_productsListUl__nn0LK",
	"productItemContainer": "course_productItemContainer__PzOF7",
	"productItemTextFull": "course_productItemTextFull___mmIW",
	"productItemTextFullIn": "course_productItemTextFullIn__fNvVp",
	"productItemText": "course_productItemText__K5uPT",
	"productItemImg": "course_productItemImg__W1R_5",
	"productItemText2": "course_productItemText2__Xtj48",
	"productItemText2_desc": "course_productItemText2_desc__0zf0d",
	"filterImg": "course_filterImg__cFKm8",
	"filterItemsContainer": "course_filterItemsContainer__LQUM8",
	"filterItemCat": "course_filterItemCat__Lqd2D",
	"filterItemTitle": "course_filterItemTitle__p_rwk",
	"filterItemInput": "course_filterItemInput__k3Rwt",
	"filterItemInputLabel": "course_filterItemInputLabel__atKPv",
	"realLeftSide": "course_realLeftSide__xi0IT",
	"realLeftSide_greyTitle": "course_realLeftSide_greyTitle__FmmmF",
	"realLeftSide_lines": "course_realLeftSide_lines__378Il",
	"realLeftSide_lines_a": "course_realLeftSide_lines_a__kPkj1",
	"realLeftSide_lines_b": "course_realLeftSide_lines_b__WovCy",
	"realLeftSide_lines_b_iconContainer": "course_realLeftSide_lines_b_iconContainer__Fp24e",
	"realLeftSide_lines_b_iconCover": "course_realLeftSide_lines_b_iconCover__JgZiW",
	"realLeftSide_lines_b_icon": "course_realLeftSide_lines_b_icon__3kXnf",
	"realLeftSide_blueTitle": "course_realLeftSide_blueTitle__3V9_x",
	"realLeftSide_form_input": "course_realLeftSide_form_input__rD_D5",
	"realLeftSide_form_button": "course_realLeftSide_form_button__WCFWv",
	"courseInfoTitle1": "course_courseInfoTitle1__jKEDR",
	"courseInfoTitle2": "course_courseInfoTitle2__evHB0"
};


/***/ }),

/***/ 2924:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4601);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_NavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1967);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4486);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_animated_checkbox__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3061);
/* harmony import */ var react_animated_checkbox__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_animated_checkbox__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_iconComponent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4310);
/* harmony import */ var react_web_share__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1278);
/* harmony import */ var react_web_share__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_web_share__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1564);
/* harmony import */ var validator__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(validator__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3060);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_12__]);
react_toastify__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable react/no-unescaped-entities */ 


















const LeftSide = ({ course , lang  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)([
        "common",
        "course"
    ]);
    const form = (0,react__WEBPACK_IMPORTED_MODULE_6__.useRef)();
    const { 0: from_email , 1: setFromEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("");
    const { 0: full_name , 1: setFull_name  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("");
    const { 0: phone , 1: setPhone  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("");
    const message = `הרשמה לקורס: <a href='${window.location.href}'>${course.title}</a>`;
    const { 0: sendStatus , 1: setSendStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const teachers_arr = [
        {
            teacher: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "teacher1"),
            phone: course.phone1
        }, 
    ];
    if (course.teacher2 && course.teacher2.trim() !== "") {
        teachers_arr.push({
            teacher: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "teacher2"),
            phone: course.phone2
        });
    }
    if (course.teacher3 && course.teacher3.trim() !== "") {
        teachers_arr.push({
            teacher: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "teacher3"),
            phone: course.phone3
        });
    }
    if (course.teacher4 && course.teacher4.trim() !== "") {
        teachers_arr.push({
            teacher: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "teacher4"),
            phone: course.phone4
        });
    }
    if (course.teacher5 && course.teacher5.trim() !== "") {
        teachers_arr.push({
            teacher: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "teacher5"),
            phone: course.phone5
        });
    }
    console.log(sendStatus, "ttt");
    const notify = (msg, type)=>{
        react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.dismiss();
        if (type === "success") {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.success(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        } else {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.error(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    textAlign: "center"
                },
                children: msg
            }), {
                theme: "colored"
            });
        }
    };
    const sendEmail = async (e)=>{
        e.preventDefault();
        setSendStatus(true);
        const inputData = e.target.elements;
        if (inputData.full_name) {
            if (validator__WEBPACK_IMPORTED_MODULE_15___default().isAlpha(inputData.full_name.value, [
                "he"
            ], {
                ignore: " "
            }) || validator__WEBPACK_IMPORTED_MODULE_15___default().isAlpha(inputData.full_name.value, [
                "en-US"
            ], {
                ignore: " "
            })) {
                console.log("valid name");
            } else {
                notify(`${t("contact:fullnameerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.phone) {
            if (validator__WEBPACK_IMPORTED_MODULE_15___default().isMobilePhone(inputData.phone.value, [
                "he-IL"
            ])) {
                console.log("valid phone");
            } else {
                notify(`${t("contact:phoneerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        if (inputData.from_email) {
            if (validator__WEBPACK_IMPORTED_MODULE_15___default().isEmail(inputData.from_email.value)) {
                console.log("valid email");
            } else {
                // alert("Enter valid Email!");
                notify(`${t("contact:emailerror")}`, "error");
                setSendStatus(false);
                return;
            }
        }
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_14___default().sendForm("service_y0z1qup", process.env.EMAILJS_TEMPLATE_ID_COURSE, form.current, "y9eqDlIW1ZnKzAxVt").then((result)=>{
            notify(`${t("contact:formsuccess")}`, "success");
            setFromEmail("");
            setFull_name("");
            setPhone("");
            setSendStatus(false);
        // inputData.from_email.value = "";
        // inputData.full_name.value = "";
        // inputData.phone.value = "";
        // inputData.company.value = "";
        // inputData.message.value = "";
        }, (error)=>{
            setSendStatus(false);
            notify(`${t("contact:formerror")}`, "error");
        });
    };
    const TeacherRow = ({ lang  })=>{
        return teachers_arr.map((item, index)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, item, "teacher")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            href: `tel:${item.phone}`,
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                            activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                            title: item.phone
                        })
                    })
                ]
            }, index);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_greyTitle),
                style: {
                    borderRadius: "20px 20px 0 0"
                },
                children: t("course:coursedetails")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: [
                            t("common:category"),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            href: "",
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                            activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                            title: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course.cat_data, "title")
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: [
                            t("course:courselength"),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "coursetime")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: [
                            t("course:startdate"),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: course.startdate
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_greyTitle),
                children: t("course:coursecoo")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TeacherRow, {
                lang: lang
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_greyTitle),
                children: t("course:interested")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: t("course:sendtofriend")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_web_share__WEBPACK_IMPORTED_MODULE_11__.RWebShare, {
                            data: {
                                text: `${(0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "description")}`,
                                url: window.location.href,
                                title: `${(0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "title")}`
                            },
                            onClick: ()=>console.log("shared successfully!"),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_iconContainer),
                                style: {
                                    cursor: "pointer"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_iconCover),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        name: "fa-sharp fa-solid fa-envelope-open-text",
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_icon)
                                    })
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: t("course:downloadregisterdoc")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            href: `${"https://qrs-global.com"}/uploads/${(0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "file")}`,
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                            activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                            title: "",
                            target: "_blank",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_iconContainer),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_iconCover),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        name: "fa-sharp fa-solid fa-download",
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_icon)
                                    })
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_a),
                        children: t("course:onlineregister")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_iconContainer),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_iconCover),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    name: "fa-sharp fa-solid fa-file-invoice",
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_lines_b_icon)
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_blueTitle),
                children: [
                    t("course:moreinfo"),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("br", {}),
                    t("course:filldetails")
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                ref: form,
                onSubmit: sendEmail,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_form_input),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                            type: "text",
                            name: "full_name",
                            placeholder: t("common:fullname"),
                            value: full_name,
                            onChange: (e)=>setFull_name(e.target.value)
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_form_input),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                            type: "text",
                            name: "phone",
                            placeholder: t("common:phone"),
                            value: phone,
                            onChange: (e)=>setPhone(e.target.value)
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_form_input),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                type: "text",
                                name: "from_email",
                                placeholder: t("common:email"),
                                value: from_email,
                                onChange: (e)=>setFromEmail(e.target.value)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                type: "hidden",
                                name: "message",
                                value: message
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                        type: "hidden",
                        name: "courseData"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().realLeftSide_form_button),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                            disabled: sendStatus,
                            type: "submit",
                            children: sendStatus ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_16___default()), {
                                color: "#ffffff",
                                size: 15,
                                "aria-label": "Loading Spinner",
                                "data-testid": "loader"
                            }) : t("common:send")
                        })
                    })
                ]
            })
        ]
    });
};
const CourseIn = ({ course , lang  })=>{
    const siteData = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)(_store_slices_generalSlice__WEBPACK_IMPORTED_MODULE_7__/* .showSiteData */ .KE);
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)([
        "common",
        "course"
    ]);
    //dispacher example to update states
    // const dispatcher = useDispatch();
    // useEffect(() => {
    //   name.name === 'mikha'
    //     ? dispatcher(nameAction.nameSamar())
    //     : dispatcher(nameAction.nameMikha());
    // }, []);
    //useSelector example to read states
    // let icon = useSelector((state) => state.icon);
    // let name = useSelector((state) => state.name);
    if (!course) {
        return;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_8___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                        children: [
                            siteData["Title"],
                            " | ",
                            (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "title")
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageCover",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().pageCover),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    alt: "page cover",
                    src: "/img/courseincover.png",
                    layout: "fill",
                    objectFit: "cover"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "pageData",
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().pageData),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "pageDataIn",
                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().pageDataInContainer),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().courseInfoContainer),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: `${(_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().courseInfoTitle)} ${(_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().courseInfoTitle1)}`,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().contentMainTitle_copy),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().titleIconContainer),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_iconComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                    name: "fa-sharp fa-solid fa-chalkboard-user",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().titleIcon)
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                                                children: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "title")
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().courseInfoNav),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navDataDiv),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().pageNavigator),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink),
                                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                                                    title: t("common:home")
                                                }),
                                                "/",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/serves",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink),
                                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                                                    title: t("common:serves")
                                                }),
                                                "/",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_NavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/serves/25",
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink),
                                                    activeClassName: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().navlink__active),
                                                    title: t("course:coursesandtutorials")
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: `${(_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().courseInfoTitle)} ${(_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().courseInfoTitle2)}`,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().contentMainTitle_copy),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                                            children: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "title")
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            id: "pageDataIn",
                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().pageDataIn),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsContainer),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsHeader),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsHeaderActive),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsHeaderActiveTitle),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", {
                                                        children: t("course:aboutcourse")
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsList),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsListIn),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().productsListUl),
                                                    dangerouslySetInnerHTML: {
                                                        __html: (0,_utils_helperFunctions__WEBPACK_IMPORTED_MODULE_17__/* .whatLanguage */ .V)(lang, course, "text")
                                                    }
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().filterContainer),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().filterContainerIn),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().filterItemsContainer),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(LeftSide, {
                                                    course: course,
                                                    lang: lang
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().filterCircle),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_18___default().filterCircleIn)
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
// ProductsIn.title = `Products`;
async function getServerSideProps({ locale , params  }) {
    const res = await fetch(`${"https://qrs-global.com"}/react/courses/index.php?id=${params.id}`);
    const course = await res.json();
    if (false) {}
    return {
        props: {
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__.serverSideTranslations)(locale ?? "he"),
            course: course?.allcourses,
            lang: locale ?? "he"
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CourseIn); // import connectMongo from '../../utils/dbConnect';
 // import Samar from '../../models/toursModel';
 // const About = ({ samars }) => {
 //   return (
 //     <div>
 //       {samars.map((samars) => (
 //         <div key={samars._id}>{samars.name}</div>
 //       ))}
 //     </div>
 //   );
 // };
 // About.title = 'About';
 // export const getServerSideProps = async () => {
 //   try {
 //     console.log('connecting to mongo');
 //     await connectMongo();
 //     console.log('connected to mongo');
 //     console.log('Fetching documents');
 //     const samars = await Samar.find();
 //     console.log('fetched documents');
 //     return {
 //       props: {
 //         samars: JSON.parse(JSON.stringify(samars)),
 //       },
 //     };
 //   } catch (err) {
 //     return {
 //       notFound: true,
 //     };
 //   }
 // };
 // export default About;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/fontawesome-svg-core");

/***/ }),

/***/ 5368:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ 197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-regular-svg-icons");

/***/ }),

/***/ 6466:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

"use strict";
module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3061:
/***/ ((module) => {

"use strict";
module.exports = require("react-animated-checkbox");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 1278:
/***/ ((module) => {

"use strict";
module.exports = require("react-web-share");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1564:
/***/ ((module) => {

"use strict";
module.exports = require("validator");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967,983], () => (__webpack_exec__(2924)));
module.exports = __webpack_exports__;

})();