(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 7:
/***/ ((module) => {

// Exports
module.exports = {
	"homeSlider": "index_homeSlider__UOih2",
	"absoluteCarousel": "index_absoluteCarousel__T2K54",
	"carouselContainer": "index_carouselContainer__V6bQH",
	"carousel__item": "index_carousel__item__MVYyl",
	"carousel__prev": "index_carousel__prev__TiesV",
	"carousel__next": "index_carousel__next__ItPQh",
	"pageCover": "index_pageCover__e7VU6",
	"coverTitle": "index_coverTitle__Ho3go",
	"pageData": "index_pageData__9IYpo",
	"homeCircles": "index_homeCircles__M_i9Y",
	"homeCircleContainer": "index_homeCircleContainer__gfOrC",
	"homeCircleCenter": "index_homeCircleCenter__bADCr",
	"homeCircleItem": "index_homeCircleItem__keAUI",
	"homeCircleItem__img_wrapper": "index_homeCircleItem__img_wrapper__piUiI",
	"homeCircleItem__img": "index_homeCircleItem__img___xWyF",
	"homeCircleItem__title": "index_homeCircleItem__title__EEIrn",
	"homeCircleItem__desc": "index_homeCircleItem__desc__N1YlG",
	"circlelink": "index_circlelink__tEuFS"
};


/***/ }),

/***/ 9759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/NavLink/index.js
var NavLink = __webpack_require__(1967);
// EXTERNAL MODULE: ./pages/index.module.css
var index_module = __webpack_require__(7);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./store/slices/generalSlice.js
var generalSlice = __webpack_require__(4486);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: ./utils/helperFunctions.js
var helperFunctions = __webpack_require__(8365);
;// CONCATENATED MODULE: ./pages/index.js















const Home = ({ circles , lang  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{
        dispatch((0,generalSlice/* getSiteDataAsync */.Ah)());
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const router = (0,router_.useRouter)();
    const sliderSettings = {
        dots: true,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 500,
        arrows: false,
        dots: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        rtl: router.locale === "he"
    };
    const siteData = (0,external_react_redux_.useSelector)(generalSlice/* showSiteData */.KE);
    const { t  } = (0,external_next_i18next_.useTranslation)([
        "common",
        "course"
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("meta", {
                                charSet: "utf-8"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("title", {
                                children: siteData?.["Title"]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
                        ...sliderSettings,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: (index_module_default()).pageCover,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                    alt: "page cover",
                                    src: "/img/homecover.jpg",
                                    layout: "fill",
                                    objectFit: "cover"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: (index_module_default()).pageCover,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                    alt: "page cover",
                                    src: "/img/servescover.jpg",
                                    layout: "fill",
                                    objectFit: "cover"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: (index_module_default()).pageCover,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                    alt: "page cover",
                                    src: "/img/servescover.jpg",
                                    layout: "fill",
                                    objectFit: "cover"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("section", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    id: "homeCircles",
                    className: (index_module_default()).homeCircles,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        id: "homeCircleContainer",
                        className: (index_module_default()).homeCircleContainer,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            id: "homeCircleCenter",
                            className: (index_module_default()).homeCircleCenter,
                            children: circles && circles.circles.map((item)=>{
                                return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                    className: (index_module_default()).homeCircleItem,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(NavLink/* default */.Z, {
                                        href: `/${(0,helperFunctions/* whatLanguage */.V)(lang, item, "url")}`,
                                        className: (index_module_default()).circlelink,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (index_module_default()).homeCircleItem__img,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                    className: (index_module_default()).homeCircleItem__img_wrapper,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                                        alt: "page cover",
                                                        src: `https://qrs-global.com/uploads/${item.pic}`,
                                                        layout: "responsive",
                                                        width: 286,
                                                        height: 284
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (index_module_default()).homeCircleItem__title,
                                                children: (0,helperFunctions/* whatLanguage */.V)(lang, item, "title")
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (index_module_default()).homeCircleItem__desc,
                                                children: (0,helperFunctions/* whatLanguage */.V)(lang, item, "description")
                                            })
                                        ]
                                    })
                                }, item.id);
                            })
                        })
                    })
                })
            })
        ]
    });
};
const getStaticProps = async ({ locale  })=>{
    const res1 = await fetch("https://qrs-global.com/react/home/index.php");
    const data1 = await res1.json();
    if (false) {}
    return {
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale ?? "he"),
            circles: data1,
            lang: locale ?? "he"
        }
    };
};
// Home.title = 'QRS MEDICAL';
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967], () => (__webpack_exec__(9759)));
module.exports = __webpack_exports__;

})();