(() => {
var exports = {};
exports.id = 304;
exports.ids = [304];
exports.modules = {

/***/ 6410:
/***/ ((module) => {

// Exports
module.exports = {
	"pageCover": "indexcat_pageCover__Q4mS5",
	"pageData": "indexcat_pageData__41UmV",
	"pageDataIn": "indexcat_pageDataIn__dd6CQ",
	"productsContainer": "indexcat_productsContainer__RGWdP",
	"filterContainer": "indexcat_filterContainer__2EZd9",
	"filterContainerIn": "indexcat_filterContainerIn__5NGQc",
	"filterCircle": "indexcat_filterCircle__Nemwa",
	"filterCircleIn": "indexcat_filterCircleIn__2TUxS",
	"productsHeader": "indexcat_productsHeader___9bOq",
	"productsHeaderDead": "indexcat_productsHeaderDead__o33go",
	"productsHeaderActive": "indexcat_productsHeaderActive__FGNaF",
	"productsHeaderActiveTitle": "indexcat_productsHeaderActiveTitle__7cMOL",
	"productsHeaderActiveNav": "indexcat_productsHeaderActiveNav__LN0Mf",
	"pageNavigator": "indexcat_pageNavigator__QSFWL",
	"navlink": "indexcat_navlink___W4XD",
	"navlink__active": "indexcat_navlink__active__SpBqY",
	"productsList": "indexcat_productsList__ltY7g",
	"productsListIn": "indexcat_productsListIn__RdXhF",
	"productsListUl": "indexcat_productsListUl__Gu2BK",
	"productItemContainer": "indexcat_productItemContainer__9rd5T",
	"productItemTextFull": "indexcat_productItemTextFull__yft2B",
	"productItemTextFullIn": "indexcat_productItemTextFullIn__6ecPo",
	"productItemText": "indexcat_productItemText__yo4tI",
	"productItemImg": "indexcat_productItemImg__OOLw7",
	"productItemText2": "indexcat_productItemText2__RkYQd",
	"productItemText2_desc": "indexcat_productItemText2_desc__u2E2H",
	"filterImg": "indexcat_filterImg__bQZXP",
	"filterItemsContainer": "indexcat_filterItemsContainer__NQj0x",
	"filterItemCat": "indexcat_filterItemCat___971M",
	"filterItemTitle": "indexcat_filterItemTitle__X13t_",
	"filterItemInput": "indexcat_filterItemInput__5Y_Bq",
	"filterItemInputLabel": "indexcat_filterItemInputLabel__l8uC9",
	"checkbox": "indexcat_checkbox__fFw_D",
	"loader": "indexcat_loader__Y6p2b"
};


/***/ }),

/***/ 3651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./pages/products/indexcat.module.css
var indexcat_module = __webpack_require__(6410);
var indexcat_module_default = /*#__PURE__*/__webpack_require__.n(indexcat_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/NavLink/index.js
var NavLink = __webpack_require__(1967);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./store/slices/generalSlice.js
var generalSlice = __webpack_require__(4486);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "ariakit/checkbox"
const checkbox_namespaceObject = require("ariakit/checkbox");
;// CONCATENATED MODULE: external "ariakit/group"
const group_namespaceObject = require("ariakit/group");
// EXTERNAL MODULE: external "react-spinners/BeatLoader"
var BeatLoader_ = __webpack_require__(3060);
var BeatLoader_default = /*#__PURE__*/__webpack_require__.n(BeatLoader_);
// EXTERNAL MODULE: ./utils/helperFunctions.js
var helperFunctions = __webpack_require__(8365);
;// CONCATENATED MODULE: ./pages/products/[id].js
/* eslint-disable react/no-unescaped-entities */ 









// import CheckBox from "react-animated-checkbox";





const ProductsIn = ({ productscats , catproducts , features , lang  })=>{
    const siteData = (0,external_react_redux_.useSelector)(generalSlice/* showSiteData */.KE);
    const { t  } = (0,external_next_i18next_.useTranslation)([
        "common",
        "products"
    ]);
    const form = (0,external_react_.useRef)();
    const checkbox = (0,checkbox_namespaceObject.useCheckboxState)({
        defaultValue: []
    });
    //may i need to use later...
    const { 0: checkboxes , 1: setCheckboxes  } = (0,external_react_.useState)(checkbox.value);
    const { 0: products , 1: setProducts  } = (0,external_react_.useState)(catproducts);
    const { 0: loadingProducts , 1: setLoadingProducts  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const { id  } = router.query;
    (0,external_react_.useEffect)(()=>{
        setProducts(catproducts);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const updateProducts = async (evt)=>{
        setLoadingProducts(true);
        let newarr = [
            ...checkbox.value
        ];
        const value = evt.target.value;
        if (newarr.includes(value)) {
            //remove
            const index = newarr.indexOf(value);
            if (index > -1) {
                // only splice array when item is found
                newarr.splice(index, 1); // 2nd parameter means remove one item only
            }
        } else {
            //add
            newarr.push(value);
        }
        setCheckboxes(newarr);
        console.log(JSON.stringify(newarr), "zz");
        const res2 = await fetch(typeof newarr !== undefined && newarr.length > 0 ? `${"https://qrs-global.com"}/react/productscats/catproducts.php?id=${id}&features=${JSON.stringify(newarr)}` : `${"https://qrs-global.com"}/react/productscats/catproducts.php?id=${id}`);
        const data2 = await res2.json();
        setProducts([]);
        data2 && setProducts(data2.catproducts);
        setLoadingProducts(false);
    };
    if (!products) {
        //loading or return...
        return;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            siteData["Title"],
                            " | ",
                            (0,helperFunctions/* whatLanguage */.V)(lang, productscats, "title")
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                id: "pageCover",
                className: (indexcat_module_default()).pageCover,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                    alt: "page cover",
                    src: "/img/productscover.png",
                    layout: "fill",
                    objectFit: "cover"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                id: "pageData",
                className: (indexcat_module_default()).pageData,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "pageDataIn",
                    className: (indexcat_module_default()).pageDataIn,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (indexcat_module_default()).productsContainer,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (indexcat_module_default()).productsHeader,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                            className: (indexcat_module_default()).productsHeaderDead
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (indexcat_module_default()).productsHeaderActive,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                    className: (indexcat_module_default()).productsHeaderActiveTitle,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                        children: (0,helperFunctions/* whatLanguage */.V)(lang, productscats, "title")
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                    className: (indexcat_module_default()).productsHeaderActiveNav,
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: (indexcat_module_default()).pageNavigator,
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                                                href: "/",
                                                                className: (indexcat_module_default()).navlink,
                                                                activeClassName: (indexcat_module_default()).navlink__active,
                                                                title: t("common:home")
                                                            }),
                                                            "/",
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                                                href: "/products",
                                                                className: (indexcat_module_default()).navlink,
                                                                activeClassName: (indexcat_module_default()).navlink__active,
                                                                title: t("common:products")
                                                            }),
                                                            "/",
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                                                href: `/products/${productscats.id}`,
                                                                className: (indexcat_module_default()).navlink,
                                                                activeClassName: (indexcat_module_default()).navlink__active,
                                                                title: (0,helperFunctions/* whatLanguage */.V)(lang, productscats, "title")
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                    className: (indexcat_module_default()).productsList,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                        className: (indexcat_module_default()).productsListIn,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                                            className: (indexcat_module_default()).productsListUl,
                                            children: !loadingProducts && products ? products.map((item)=>{
                                                return /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(NavLink/* default */.Z, {
                                                        href: `/products/in/${item.id}`,
                                                        className: "",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: (indexcat_module_default()).productItemContainer,
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: `${(indexcat_module_default()).layer}`
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: (indexcat_module_default()).productItemImg,
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                                                        alt: "page cover",
                                                                        src: `${"https://qrs-global.com"}/uploads/${item.pic}`,
                                                                        width: 221,
                                                                        height: 221,
                                                                        objectFit: "scale-down"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: (indexcat_module_default()).productItemText,
                                                                    children: (0,helperFunctions/* whatLanguage */.V)(lang, item, "title")
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: (indexcat_module_default()).productItemTextFull,
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: (indexcat_module_default()).productItemTextFullIn,
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                                className: (indexcat_module_default()).productItemText2,
                                                                                children: (0,helperFunctions/* whatLanguage */.V)(lang, item, "title")
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                                className: (indexcat_module_default()).productItemText2_desc,
                                                                                dangerouslySetInnerHTML: {
                                                                                    __html: (0,helperFunctions/* whatLanguage */.V)(lang, item, "text")
                                                                                }
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }, item.id);
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                className: (indexcat_module_default()).loader,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((BeatLoader_default()), {
                                                    color: "#004b8d",
                                                    size: 15,
                                                    "aria-label": "Loading Spinner",
                                                    "data-testid": "loader"
                                                })
                                            })
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (indexcat_module_default()).filterContainer,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (indexcat_module_default()).filterContainerIn,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                            className: (indexcat_module_default()).filterImg,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                                alt: "page cover",
                                                src: `${"https://qrs-global.com"}/uploads/${productscats.pic}`,
                                                width: 218,
                                                height: 171,
                                                objectFit: "scale-down"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                            className: (indexcat_module_default()).filterItemsContainer,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("form", {
                                                ref: form,
                                                children: features?.map((item)=>{
                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                        className: (indexcat_module_default()).filterItemCat,
                                                        children: item.cat_items.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(group_namespaceObject.Group, {
                                                            className: "wrapper",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                    className: (indexcat_module_default()).filterItemTitle,
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(group_namespaceObject.GroupLabel, {
                                                                        children: (0,helperFunctions/* whatLanguage */.V)(lang, item.cat_data, "title")
                                                                    })
                                                                }),
                                                                item.cat_items.map((catitem)=>{
                                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                                        className: (indexcat_module_default()).filterItemInput,
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                            className: (indexcat_module_default()).container,
                                                                            children: [
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)(checkbox_namespaceObject.Checkbox, {
                                                                                    state: checkbox,
                                                                                    value: catitem.id,
                                                                                    className: (indexcat_module_default()).checkbox,
                                                                                    onChange: updateProducts
                                                                                }),
                                                                                " ",
                                                                                (0,helperFunctions/* whatLanguage */.V)(lang, catitem, "title")
                                                                            ]
                                                                        })
                                                                    }, catitem.id);
                                                                })
                                                            ]
                                                        })
                                                    }, item.cat_data.id);
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                    className: (indexcat_module_default()).filterCircle,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                        className: (indexcat_module_default()).filterCircleIn
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
// ProductsIn.title = `Products`;
async function getServerSideProps({ locale , params  }) {
    const res1 = await fetch(`${"https://qrs-global.com"}/react/productscats/index.php?id=${params.id}`);
    const data1 = await res1.json();
    const res2 = await fetch(`${"https://qrs-global.com"}/react/productscats/catproducts.php?id=${params.id}`);
    const data2 = await res2.json();
    const res3 = await fetch(`${"https://qrs-global.com"}/react/products/features.php`);
    const data3 = await res3.json();
    if (false) {}
    return {
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale ?? "he"),
            productscats: data1?.productscats,
            catproducts: data2?.catproducts,
            features: data3?.productsfeatures,
            lang: locale ?? "he"
        }
    };
}
/* harmony default export */ const _id_ = (ProductsIn); // import connectMongo from '../../utils/dbConnect';
 // import Samar from '../../models/toursModel';
 // const About = ({ samars }) => {
 //   return (
 //     <div>
 //       {samars.map((samars) => (
 //         <div key={samars._id}>{samars.name}</div>
 //       ))}
 //     </div>
 //   );
 // };
 // About.title = 'About';
 // export const getServerSideProps = async () => {
 //   try {
 //     console.log('connecting to mongo');
 //     await connectMongo();
 //     console.log('connected to mongo');
 //     console.log('Fetching documents');
 //     const samars = await Samar.find();
 //     console.log('fetched documents');
 //     return {
 //       props: {
 //         samars: JSON.parse(JSON.stringify(samars)),
 //       },
 //     };
 //   } catch (err) {
 //     return {
 //       notFound: true,
 //     };
 //   }
 // };
 // export default About;


/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ whatLanguage)
/* harmony export */ });
/* unused harmony export useWidth */
const useWidth = ()=>{
    const [width, setWidth] = useState(0);
    const handleResize = ()=>setWidth(window.innerWidth);
    useEffect(()=>{
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, [
        width
    ]);
    return width;
};
const whatLanguage = (lang, obj, value)=>{
    if (lang === "en") {
        if (obj && obj[value + "_en"] !== "" && obj[value + "_en"] !== null) {
            return obj[value + "_en"];
        } else {
            return obj[value];
        }
    } else {
        return obj[value];
    }
};


/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,486,967], () => (__webpack_exec__(3651)));
module.exports = __webpack_exports__;

})();